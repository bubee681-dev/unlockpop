package dev.bonu.unlockpop;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.media.AudioManager;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;

/**
 * Live state for the two extra dots: they light up during a ringing call, an active call and
 * music, without changing size like an island. Drawn on top of the black dots by DotsView.
 */
final class LiveDots {
    private static final int NONE = 0, RING = 1, CALL = 2, MUSIC = 3;
    private static final int GREEN = 0x34C759, BLUE = 0x378ADD, CORAL = 0xFF6B8B;
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final Paint P = new Paint(Paint.ANTI_ALIAS_FLAG);
    private static final RectF R = new RectF();

    static volatile DotsView view;
    private static boolean started;
    private static AudioManager am;
    private static int mode = NONE;
    private static int shown = NONE;
    private static long modeSince;
    private static long callStart;
    private static long lastDraw;
    private static float level;

    private LiveDots() {}

    static void init(Context c) {
        if (started) return;
        started = true;
        try {
            am = (AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
            MAIN.post(new Runnable() {
                @Override
                public void run() {
                    try {
                        poll();
                    } catch (Throwable ignored) {
                    }
                    MAIN.postDelayed(this, 500);
                }
            });
        } catch (Throwable ignored) {
        }
    }

    private static void poll() {
        int m = NONE;
        if (Config.dots && am != null) {
            int am0 = am.getMode();
            if (am0 == AudioManager.MODE_RINGTONE) m = RING;
            else if (am0 == AudioManager.MODE_IN_CALL || am0 == AudioManager.MODE_IN_COMMUNICATION) m = CALL;
            else if (am.isMusicActive()) m = MUSIC;
        }
        long now = SystemClock.uptimeMillis();
        if (m != mode) {
            if (m == CALL) callStart = now;
            mode = m;
            modeSince = now;
            if (m != NONE) shown = m;
        }
        DotsView v = view;
        if (v != null && active()) v.postInvalidate();
    }

    static boolean active() {
        return mode != NONE || level > 0.001f;
    }

    private static int argb(int rgb, float a) {
        int al = (int) (Math.max(0f, Math.min(1f, a)) * 255f);
        return (al << 24) | (rgb & 0xFFFFFF);
    }

    static void draw(Canvas c, float cx, float cy, float r0, int layout, float dxPx, float dyPx) {
        long now = SystemClock.uptimeMillis();
        float dt = lastDraw == 0 ? 16f : Math.min(50f, now - lastDraw);
        lastDraw = now;
        if (mode != NONE) level = Math.min(1f, level + dt / 200f);
        else level = Math.max(0f, level - dt / 300f);
        if (level <= 0.001f) {
            lastDraw = 0;
            return;
        }

        float k = r0 / 10f;
        float step = 2.9f * r0;
        float[] o;
        if (layout == 1) o = new float[]{-step, -2f * step};
        else if (layout == 2) o = new float[]{step, 2f * step};
        else o = new float[]{-step, step};
        float rad = Math.max(0.5f, r0 * 0.92f);
        float t = (now - modeSince) / 1000f;

        for (int i = 0; i < 2; i++) {
            int color = GREEN;
            float glow = 0f, scale = 1f, ring = -1f, rip = -1f;
            if (shown == RING) {
                float ph = ((t / 1.4f) + (i == 0 ? 0f : 0.5f)) % 1f;
                float g = 0.5f - 0.5f * (float) Math.cos(2.0 * Math.PI * ph);
                glow = 0.3f + 0.7f * g;
                scale = 1f + 0.06f * g;
                rip = ph;
            } else if (shown == CALL) {
                if (i == 0) {
                    glow = 0.5f + 0.15f * (float) Math.sin(t * 1.6f);
                } else {
                    glow = 0.22f;
                    float el = (now - callStart) / 1000f;
                    ring = (el % 60f) / 60f;
                }
            } else if (shown == MUSIC) {
                float b = t * 118f / 60f;
                if (i == 0) {
                    float kick = (float) Math.exp(-6.0 * (b % 1f));
                    color = CORAL;
                    glow = 0.2f + 0.8f * kick;
                    scale = 1f + 0.2f * kick;
                } else {
                    float h = (b * 2f + 0.5f) % 1f;
                    float hat = (float) Math.exp(-9.0 * h) * (0.65f + 0.35f * (float) Math.sin(t * 3.1f));
                    color = BLUE;
                    glow = 0.15f + 0.85f * hat;
                    scale = 1f + 0.14f * hat;
                }
            }
            one(c, cx + o[i] + dxPx, cy + dyPx, rad, k, color, glow * level, scale, ring, rip, level);
        }
    }

    private static void one(Canvas c, float x, float y, float rad, float k, int color,
                            float glow, float scale, float ring, float rip, float level) {
        float r = rad * scale;
        P.setStyle(Paint.Style.FILL);
        P.setColor(argb(color, glow * 0.10f));
        c.drawCircle(x, y, r * 1.8f, P);
        P.setColor(argb(color, glow * 0.18f));
        c.drawCircle(x, y, r * 1.5f, P);
        P.setColor(argb(color, glow * 0.30f));
        c.drawCircle(x, y, r * 1.25f, P);
        P.setColor(argb(color, glow));
        c.drawCircle(x, y, r, P);

        P.setStyle(Paint.Style.STROKE);
        if (ring >= 0f) {
            float rr = rad + 3.6f * k;
            P.setStrokeWidth(1.8f * k);
            P.setStrokeCap(Paint.Cap.ROUND);
            P.setColor(argb(0xFFFFFF, 0.14f * level));
            c.drawCircle(x, y, rr, P);
            P.setColor(argb(color, level));
            R.set(x - rr, y - rr, x + rr, y + rr);
            c.drawArc(R, -90f, Math.max(2f, ring * 360f), false, P);
            P.setStrokeCap(Paint.Cap.BUTT);
        }
        if (rip >= 0f) {
            P.setStrokeWidth(1.6f * k);
            P.setColor(argb(color, (1f - rip) * 0.75f * level));
            c.drawCircle(x, y, rad + rip * 16f * k, P);
        }
        P.setStyle(Paint.Style.FILL);
    }
}
