package dev.bonu.unlockpop;

import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

import java.util.HashMap;
import java.util.Map;

import de.robv.android.xposed.XposedBridge;

final class Overlay {
    private static final String TAG = "UnlockPop: ";
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final Map<String, Long> SEEN = new HashMap<>();
    private static Context appCtx;
    private static boolean inited;
    private static long startAt;
    private static PopView view;
    private static DotsView dotsView;
    private static long last;

    private Overlay() {}

    static void init(Context ctx) {
        if (inited) return;
        inited = true;
        appCtx = ctx;
        startAt = SystemClock.uptimeMillis();

        BroadcastReceiver r = new BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent i) {
                try {
                    if (i == null) return;
                    if (MainHook.ACTION_CFG.equals(i.getAction())) {
                        Config.refresh(c);
                        return;
                    }
                    play(i.getStringExtra("type"), i.getIntExtra("kind", 0),
                            i.getStringExtra("label"), i.getBooleanExtra("test", false));
                } catch (Throwable t) {
                    XposedBridge.log(TAG + t);
                }
            }
        };
        IntentFilter f = new IntentFilter(MainHook.ACTION);
        f.addAction(MainHook.ACTION_CFG);
        ctx.registerReceiver(r, f, Context.RECEIVER_EXPORTED);
        Config.refresh(ctx);
        LiveDots.init(ctx);

        try {
            BroadcastReceiver bt = new BroadcastReceiver() {
                @Override
                public void onReceive(Context c, Intent i) {
                    try {
                        BluetoothDevice d = i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice.class);
                        if (d == null) return;
                        String addr = d.getAddress();
                        long now = SystemClock.uptimeMillis();
                        Long prev = SEEN.get(addr);
                        if (prev != null && now - prev < 8000) return;
                        String name = null;
                        try {
                            name = d.getName();
                        } catch (Throwable ignored) {
                        }
                        android.bluetooth.BluetoothClass bc = null;
                        try {
                            bc = d.getBluetoothClass();
                        } catch (Throwable ignored) {
                        }
                        int kind = PopView.classify(name, bc);
                        if (kind < 0) return;
                        SEEN.put(addr, now);
                        XposedBridge.log(TAG + "bluetooth " + name + " kind=" + kind);
                        play("bt", kind, name == null ? "Bluetooth device" : name, false);
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + t);
                    }
                }
            };
            ctx.registerReceiver(bt, new IntentFilter(BluetoothDevice.ACTION_ACL_CONNECTED), Context.RECEIVER_EXPORTED);

            BroadcastReceiver wr = new BroadcastReceiver() {
                @Override
                public void onReceive(Context c, Intent i) {
                    try {
                        if (SystemClock.uptimeMillis() - startAt < 3000) return;
                        if (i.getIntExtra("state", 0) != 1) return;
                        boolean mic = i.getIntExtra("microphone", 0) == 1;
                        XposedBridge.log(TAG + "wired plug mic=" + mic);
                        play("wired", mic ? 2 : 1, mic ? "Wired headset" : "Wired headphones", false);
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + t);
                    }
                }
            };
            ctx.registerReceiver(wr, new IntentFilter(Intent.ACTION_HEADSET_PLUG), Context.RECEIVER_EXPORTED);
        } catch (Throwable t) {
            XposedBridge.log(TAG + "extra receivers failed: " + t);
        }
        XposedBridge.log(TAG + "overlay receivers ready");
    }

    private static Context ctx() {
        if (appCtx != null) return appCtx;
        try {
            Class<?> at = Class.forName("android.app.ActivityThread");
            Object app = at.getMethod("currentApplication").invoke(null);
            if (app instanceof Context) appCtx = (Context) app;
        } catch (Throwable ignored) {
        }
        return appCtx;
    }

    private static boolean enabled(String type) {
        if ("bt".equals(type)) return Config.bt;
        if ("wired".equals(type)) return Config.wired;
        return Config.unlock;
    }

    static void play(final String type, final int kind, final String label, final boolean test) {
        MAIN.post(new Runnable() {
            @Override
            public void run() {
                try {
                    if (!test && !enabled(type)) return;
                    showWhenAwake(type, kind, label, 0);
                } catch (Throwable t) {
                    XposedBridge.log(TAG + "show failed: " + t);
                    view = null;
                }
            }
        });
    }

    private static void showWhenAwake(final String type, final int kind, final String label, final int tries) {
        try {
            Context c = ctx();
            if (c == null) return;
            android.os.PowerManager pm = (android.os.PowerManager) c.getSystemService(Context.POWER_SERVICE);
            boolean awake = pm == null || pm.isInteractive();
            if (!awake) {
                if (tries >= 25) return;
                MAIN.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        showWhenAwake(type, kind, label, tries + 1);
                    }
                }, 40);
                return;
            }
            if (tries > 0) {
                MAIN.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            show(type, kind, label);
                        } catch (Throwable t) {
                            XposedBridge.log(TAG + "show failed: " + t);
                            view = null;
                        }
                    }
                }, 120);
            } else {
                show(type, kind, label);
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + "wake check failed: " + t);
        }
    }

    private static void show(String type, int kind, String label) {
        long now = SystemClock.uptimeMillis();
        if (view != null || now - last < 800) return;
        Context c = ctx();
        if (c == null) return;
        last = now;
        int mode = "face".equals(type) ? 0 : ("finger".equals(type) ? 1 : 2);
        final WindowManager wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
        final boolean withDots = Config.dots && dotsView != null;
        final PopView v = new PopView(c, mode, Config.green ? PopView.GREEN : PopView.BLUE, kind, label, withDots, Config.layout);
        if (withDots) {
            v.setOnFirstFrame(new Runnable() {
                @Override
                public void run() {
                    if (dotsView != null) dotsView.setVisibility(View.INVISIBLE);
                }
            });
        }
        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED;
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, v.windowHeight(), 2024, flags, PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        lp.setTitle("UnlockPop");
        try {
            wm.addView(v, lp);
        } catch (Throwable t) {
            lp.type = 2010;
            wm.addView(v, lp);
        }
        view = v;
        v.start(new Runnable() {
            @Override
            public void run() {
                try {
                    if (dotsView != null) dotsView.setVisibility(View.VISIBLE);
                    wm.removeViewImmediate(v);
                } catch (Throwable ignored) {
                }
                view = null;
            }
        });
    }

    static void syncDots() {
        MAIN.post(new Runnable() {
            @Override
            public void run() {
                try {
                    Context c = ctx();
                    if (c == null) return;
                    WindowManager wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
                    if (Config.dots) {
                        if (dotsView == null) {
                            DotsView dv = new DotsView(c);
                            int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                                    | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                                    | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                                    | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                                    | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED;
                            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                                    WindowManager.LayoutParams.MATCH_PARENT, dv.windowHeight(), 2024, flags, PixelFormat.TRANSLUCENT);
                            lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
                            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
                            lp.setTitle("UnlockPopDots");
                            wm.addView(dv, lp);
                            dotsView = dv;
                        } else {
                            dotsView.invalidate();
                        }
                    } else if (dotsView != null) {
                        try {
                            wm.removeViewImmediate(dotsView);
                        } catch (Throwable ignored) {
                        }
                        dotsView = null;
                    }
                } catch (Throwable t) {
                    XposedBridge.log(TAG + "dots failed: " + t);
                }
            }
        });
    }
}
