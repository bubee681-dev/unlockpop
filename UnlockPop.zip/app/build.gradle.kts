plugins { id("com.android.application") }

android {
    namespace = "dev.bonu.unlockpop"
    compileSdk = 34
    defaultConfig {
        applicationId = "dev.bonu.unlockpop"
        minSdk = 30
        targetSdk = 34
        versionCode = 6
        versionName = "1.5"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    compileOnly(project(":xposed-api"))
}
