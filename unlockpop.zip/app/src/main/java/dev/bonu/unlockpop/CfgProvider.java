package dev.bonu.unlockpop;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;

public class CfgProvider extends ContentProvider {
    @Override
    public boolean onCreate() {
        return true;
    }

    @Override
    public Bundle call(String method, String arg, Bundle extras) {
        Bundle b = new Bundle();
        SharedPreferences sp = getContext().getSharedPreferences("cfg", 0);
        b.putBoolean("unlock", sp.getBoolean("unlock", true));
        b.putBoolean("bt", sp.getBoolean("bt", true));
        b.putBoolean("wired", sp.getBoolean("wired", true));
        b.putBoolean("green", "green".equals(sp.getString("color", "blue")));
        return b;
    }

    @Override
    public Cursor query(Uri u, String[] p, String s, String[] a, String o) {
        return null;
    }

    @Override
    public String getType(Uri u) {
        return null;
    }

    @Override
    public Uri insert(Uri u, ContentValues v) {
        return null;
    }

    @Override
    public int delete(Uri u, String s, String[] a) {
        return 0;
    }

    @Override
    public int update(Uri u, ContentValues v, String s, String[] a) {
        return 0;
    }
}
