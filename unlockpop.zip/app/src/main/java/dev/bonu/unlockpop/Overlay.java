package dev.bonu.unlockpop;

import android.app.PendingIntent;
import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

import java.util.HashMap;
import java.util.Map;

import de.robv.android.xposed.XposedBridge;

final class Overlay {
    private static final String TAG = "UnlockPop: ";
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static final Map<String, Long> SEEN = new HashMap<>();
    private static Context appCtx;
    private static boolean inited;
    private static long startAt;
    private static PopView view;
    private static DotsView dotsView;
    private static CallView callView;
    private static PendingIntent piAns, piDec, piEnd;
    private static long testUntil;
    private static long last;

    private Overlay() {}

    static void init(Context ctx) {
        if (inited) return;
        inited = true;
        appCtx = ctx;
        startAt = SystemClock.uptimeMillis();

        BroadcastReceiver r = new BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent i) {
                try {
                    if (i == null) return;
                    if (MainHook.ACTION_CFG.equals(i.getAction())) {
                        Config.refresh(c);
                        return;
                    }
                    play(i.getStringExtra("type"), i.getIntExtra("kind", 0),
                            i.getStringExtra("label"), i.getBooleanExtra("test", false));
                } catch (Throwable t) {
                    XposedBridge.log(TAG + t);
                }
            }
        };
        IntentFilter f = new IntentFilter(MainHook.ACTION);
        f.addAction(MainHook.ACTION_CFG);
        ctx.registerReceiver(r, f, Context.RECEIVER_EXPORTED);
        Config.refresh(ctx);
        initLive(ctx);

        try {
            BroadcastReceiver cr = new BroadcastReceiver() {
                @Override
                public void onReceive(Context c, Intent i) {
                    try {
                        onCall(i);
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + "call card: " + t);
                    }
                }
            };
            ctx.registerReceiver(cr, new IntentFilter(MainHook.ACTION_CALL),
                    "android.permission.MODIFY_PHONE_STATE", null, Context.RECEIVER_EXPORTED);
        } catch (Throwable t) {
            XposedBridge.log(TAG + "call receiver failed: " + t);
        }

        try {
            BroadcastReceiver bt = new BroadcastReceiver() {
                @Override
                public void onReceive(Context c, Intent i) {
                    try {
                        BluetoothDevice d = i.getParcelableExtra(BluetoothDevice.EXTRA_DEVICE, BluetoothDevice.class);
                        if (d == null) return;
                        String addr = d.getAddress();
                        long now = SystemClock.uptimeMillis();
                        Long prev = SEEN.get(addr);
                        if (prev != null && now - prev < 8000) return;
                        String name = null;
                        try {
                            name = d.getName();
                        } catch (Throwable ignored) {
                        }
                        android.bluetooth.BluetoothClass bc = null;
                        try {
                            bc = d.getBluetoothClass();
                        } catch (Throwable ignored) {
                        }
                        int kind = PopView.classify(name, bc);
                        if (kind < 0) return;
                        SEEN.put(addr, now);
                        XposedBridge.log(TAG + "bluetooth " + name + " kind=" + kind);
                        play("bt", kind, name == null ? "Bluetooth device" : name, false);
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + t);
                    }
                }
            };
            ctx.registerReceiver(bt, new IntentFilter(BluetoothDevice.ACTION_ACL_CONNECTED), Context.RECEIVER_EXPORTED);

            BroadcastReceiver wr = new BroadcastReceiver() {
                @Override
                public void onReceive(Context c, Intent i) {
                    try {
                        if (SystemClock.uptimeMillis() - startAt < 3000) return;
                        if (i.getIntExtra("state", 0) != 1) return;
                        boolean mic = i.getIntExtra("microphone", 0) == 1;
                        XposedBridge.log(TAG + "wired plug mic=" + mic);
                        play("wired", mic ? 2 : 1, mic ? "Wired headset" : "Wired headphones", false);
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + t);
                    }
                }
            };
            ctx.registerReceiver(wr, new IntentFilter(Intent.ACTION_HEADSET_PLUG), Context.RECEIVER_EXPORTED);
        } catch (Throwable t) {
            XposedBridge.log(TAG + "extra receivers failed: " + t);
        }
        XposedBridge.log(TAG + "overlay receivers ready");
    }

    private static Context ctx() {
        if (appCtx != null) return appCtx;
        try {
            Class<?> at = Class.forName("android.app.ActivityThread");
            Object app = at.getMethod("currentApplication").invoke(null);
            if (app instanceof Context) appCtx = (Context) app;
        } catch (Throwable ignored) {
        }
        return appCtx;
    }

    private static boolean enabled(String type) {
        if ("bt".equals(type)) return Config.bt;
        if ("wired".equals(type)) return Config.wired;
        return Config.unlock;
    }

    static void play(final String type, final int kind, final String label, final boolean test) {
        MAIN.post(new Runnable() {
            @Override
            public void run() {
                try {
                    if ("livetest".equals(type) || "livecall".equals(type) || "livemusic".equals(type)) {
                        liveTest("livecall".equals(type) ? 1 : ("livemusic".equals(type) ? 2 : 0));
                        return;
                    }
                    if ("calltest".equals(type)) {
                        showCall("Mama", "Incoming call  +234 803 123 4567", true);
                        return;
                    }
                    if (callView != null) return;
                    if (!test && !enabled(type)) return;
                    showWhenAwake(type, kind, label, 0);
                } catch (Throwable t) {
                    XposedBridge.log(TAG + "show failed: " + t);
                    view = null;
                }
            }
        });
    }

    private static void showWhenAwake(final String type, final int kind, final String label, final int tries) {
        try {
            Context c = ctx();
            if (c == null) return;
            android.os.PowerManager pm = (android.os.PowerManager) c.getSystemService(Context.POWER_SERVICE);
            boolean awake = pm == null || pm.isInteractive();
            if (!awake) {
                if (tries >= 25) return;
                MAIN.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        showWhenAwake(type, kind, label, tries + 1);
                    }
                }, 40);
                return;
            }
            if (tries > 0) {
                MAIN.postDelayed(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            show(type, kind, label);
                        } catch (Throwable t) {
                            XposedBridge.log(TAG + "show failed: " + t);
                            view = null;
                        }
                    }
                }, 120);
            } else {
                show(type, kind, label);
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + "wake check failed: " + t);
        }
    }

    private static void show(String type, int kind, String label) {
        long now = SystemClock.uptimeMillis();
        if (view != null || now - last < 800) return;
        Context c = ctx();
        if (c == null) return;
        last = now;
        int mode = "face".equals(type) ? 0 : ("finger".equals(type) ? 1 : 2);
        final WindowManager wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
        final boolean withDots = Config.dots && dotsView != null;
        final PopView v = new PopView(c, mode, Config.green ? PopView.GREEN : PopView.BLUE, kind, label, withDots, Config.layout);
        if (withDots) {
            v.setOnFirstFrame(new Runnable() {
                @Override
                public void run() {
                    if (dotsView != null) dotsView.setVisibility(View.INVISIBLE);
                }
            });
        }
        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED;
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, v.windowHeight(), 2024, flags, PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        lp.setTitle("UnlockPop");
        try {
            wm.addView(v, lp);
        } catch (Throwable t) {
            lp.type = 2010;
            wm.addView(v, lp);
        }
        view = v;
        v.start(new Runnable() {
            @Override
            public void run() {
                try {
                    if (dotsView != null) dotsView.setVisibility(View.VISIBLE);
                    wm.removeViewImmediate(v);
                } catch (Throwable ignored) {
                }
                view = null;
            }
        });
    }

    static void syncDots() {
        MAIN.post(new Runnable() {
            @Override
            public void run() {
                try {
                    Context c = ctx();
                    if (c == null) return;
                    WindowManager wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
                    if (Config.dots) {
                        if (dotsView == null) {
                            DotsView dv = new DotsView(c);
                            int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                                    | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                                    | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                                    | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                                    | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED;
                            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                                    WindowManager.LayoutParams.MATCH_PARENT, dv.windowHeight(), 2024, flags, PixelFormat.TRANSLUCENT);
                            lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
                            lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
                            lp.setTitle("UnlockPopDots");
                            wm.addView(dv, lp);
                            dotsView = dv;
                        } else {
                            dotsView.invalidate();
                        }
                    } else if (dotsView != null) {
                        try {
                            wm.removeViewImmediate(dotsView);
                        } catch (Throwable ignored) {
                        }
                        dotsView = null;
                    }
                } catch (Throwable t) {
                    XposedBridge.log(TAG + "dots failed: " + t);
                }
            }
        });
    }

    private static void sendPi(PendingIntent pi) {
        if (pi == null) return;
        try {
            pi.send();
        } catch (Throwable t) {
            XposedBridge.log(TAG + "pending intent failed: " + t);
        }
    }

    private static void telecom(boolean accept) {
        try {
            Context c = ctx();
            android.telecom.TelecomManager tm = (android.telecom.TelecomManager) c.getSystemService(Context.TELECOM_SERVICE);
            if (accept) tm.acceptRingingCall();
            else tm.endCall();
        } catch (Throwable t) {
            XposedBridge.log(TAG + "telecom fallback failed: " + t);
        }
    }

    static void onCall(Intent i) {
        if (i == null || !Config.calls) return;
        int kind = i.getIntExtra("kind", 0);
        String title = i.getStringExtra("title");
        String text = i.getStringExtra("text");
        PendingIntent ans = i.getParcelableExtra("ans", PendingIntent.class);
        PendingIntent dec = i.getParcelableExtra("dec", PendingIntent.class);
        PendingIntent end = i.getParcelableExtra("end", PendingIntent.class);
        if (kind == 0) {
            piAns = ans;
            piDec = dec;
            if (callView == null) showCall(title, text, false);
            else callView.update(title, text);
        } else {
            if (end != null) piEnd = end;
            if (callView != null) {
                if (callView.state == CallView.RING) callView.answered();
                callView.update(title, null);
            }
        }
    }

    private static int callState(Context c) {
        try {
            android.telephony.TelephonyManager tm = (android.telephony.TelephonyManager) c.getSystemService(Context.TELEPHONY_SERVICE);
            return tm.getCallState();
        } catch (Throwable ignored) {
        }
        try {
            android.media.AudioManager am = (android.media.AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
            int m = am.getMode();
            return m == 1 ? 1 : (m == 2 || m == 3 ? 2 : 0);
        } catch (Throwable ignored) {
        }
        return -1;
    }

    private static void showCall(String title, String sub, final boolean test) {
        final Context c = ctx();
        if (c == null || callView != null) return;
        final WindowManager wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
        if (view != null) {
            try {
                wm.removeViewImmediate(view);
            } catch (Throwable ignored) {
            }
            view = null;
        }
        final boolean withDots = Config.dots && dotsView != null;
        final CallView v = new CallView(c, title, sub, withDots);
        final long shownAt = SystemClock.uptimeMillis();
        if (withDots) {
            v.setOnFirstFrame(new Runnable() {
                @Override
                public void run() {
                    if (dotsView != null) dotsView.setVisibility(View.INVISIBLE);
                }
            });
        }
        v.setListener(new CallView.Listener() {
            @Override
            public void onAnswer() {
                if (!test) {
                    if (piAns != null) sendPi(piAns);
                    else telecom(true);
                }
                v.answered();
            }

            @Override
            public void onDecline() {
                if (!test) {
                    if (piDec != null) sendPi(piDec);
                    else telecom(false);
                }
                v.collapse();
            }

            @Override
            public void onEnd() {
                if (!test) {
                    if (piEnd != null) sendPi(piEnd);
                    else telecom(false);
                }
                v.collapse();
            }

            @Override
            public void onDone() {
                try {
                    if (dotsView != null) dotsView.setVisibility(View.VISIBLE);
                    wm.removeViewImmediate(v);
                } catch (Throwable ignored) {
                }
                callView = null;
                piAns = null;
                piDec = null;
                piEnd = null;
            }
        });
        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED;
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                v.windowWidth(), v.windowHeight(), 2024, flags, PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        lp.setTitle("UnlockPopCall");
        try {
            wm.addView(v, lp);
        } catch (Throwable t) {
            lp.type = 2010;
            wm.addView(v, lp);
        }
        callView = v;
        v.start();
        if (!test) {
            MAIN.postDelayed(new Runnable() {
                private int idle;

                @Override
                public void run() {
                    if (callView != v || v.state == CallView.OUT) return;
                    int cs = callState(c);
                    if (v.state == CallView.RING && cs == 2) v.answered();
                    if (cs == 0) idle++;
                    else idle = 0;
                    if (idle >= 3 && SystemClock.uptimeMillis() - shownAt > 2500) {
                        v.collapse();
                        return;
                    }
                    MAIN.postDelayed(this, 400);
                }
            }, 400);
        }
    }

    private static int modeToCall(int mode) {
        return mode == 1 ? 1 : (mode == 2 || mode == 3 ? 2 : 0);
    }

    static void liveChanged() {
        MAIN.post(new Runnable() {
            @Override
            public void run() {
                if (dotsView != null) dotsView.invalidate();
            }
        });
    }

    private static void onLive(Intent i) {
        if (i == null) return;
        String type = i.getStringExtra("type");
        if ("timer".equals(type)) {
            long end = i.getLongExtra("end", 0L);
            long now = System.currentTimeMillis();
            if (end > now) {
                if (Live.timerEnd != end) {
                    if (!Live.timerOn()) Live.timerStart = now;
                    else if (end > Live.timerStart + 1000L && Live.timerEnd < end) Live.timerStart = now;
                    Live.timerEnd = end;
                }
            }
        } else if ("timerOff".equals(type)) {
            Live.timerEnd = 0L;
        }
        liveChanged();
    }

    private static final Runnable MUSIC = new Runnable() {
        @Override
        public void run() {
            long next = 5000L;
            try {
                Context c = ctx();
                if (c != null && Config.live) {
                    android.media.AudioManager am = (android.media.AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
                    boolean m = am.isMusicActive();
                    if (m != Live.music && System.currentTimeMillis() > testUntil) {
                        Live.music = m;
                        liveChanged();
                    }
                    android.os.PowerManager pm = (android.os.PowerManager) c.getSystemService(Context.POWER_SERVICE);
                    if (pm == null || pm.isInteractive()) next = 1000L;
                }
            } catch (Throwable ignored) {
            }
            MAIN.postDelayed(this, next);
        }
    };

    private static void initLive(Context ctx) {
        try {
            BroadcastReceiver lr = new BroadcastReceiver() {
                @Override
                public void onReceive(Context c, Intent i) {
                    try {
                        onLive(i);
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + "live: " + t);
                    }
                }
            };
            ctx.registerReceiver(lr, new IntentFilter(MainHook.ACTION_LIVE),
                    "android.permission.MODIFY_PHONE_STATE", null, Context.RECEIVER_EXPORTED);
        } catch (Throwable t) {
            XposedBridge.log(TAG + "live receiver failed: " + t);
        }
        try {
            android.media.AudioManager am = (android.media.AudioManager) ctx.getSystemService(Context.AUDIO_SERVICE);
            Live.call = modeToCall(am.getMode());
            am.addOnModeChangedListener(new java.util.concurrent.Executor() {
                @Override
                public void execute(Runnable r) {
                    MAIN.post(r);
                }
            }, new android.media.AudioManager.OnModeChangedListener() {
                @Override
                public void onModeChanged(int mode) {
                    Live.call = modeToCall(mode);
                    liveChanged();
                }
            });
        } catch (Throwable t) {
            XposedBridge.log(TAG + "audio mode listener failed: " + t);
        }
        MAIN.postDelayed(MUSIC, 2000L);
    }

    private static void liveTest(int what) {
        long now = System.currentTimeMillis();
        testUntil = now + 8200L;
        Live.call = (what == 0 || what == 1) ? 2 : 0;
        Live.music = (what == 0 || what == 2);
        if (what == 0) {
            Live.timerStart = now;
            Live.timerEnd = now + 8000L;
        }
        liveChanged();
        MAIN.postDelayed(new Runnable() {
            @Override
            public void run() {
                Live.timerEnd = 0L;
                Live.music = false;
                try {
                    Context c = ctx();
                    if (c != null) {
                        android.media.AudioManager am = (android.media.AudioManager) c.getSystemService(Context.AUDIO_SERVICE);
                        Live.call = modeToCall(am.getMode());
                    } else {
                        Live.call = 0;
                    }
                } catch (Throwable t) {
                    Live.call = 0;
                }
                liveChanged();
            }
        }, 8200L);
    }
}
