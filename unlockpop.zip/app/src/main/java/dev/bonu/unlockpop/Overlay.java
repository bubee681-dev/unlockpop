package dev.bonu.unlockpop;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.PixelFormat;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.Gravity;
import android.view.WindowManager;

import de.robv.android.xposed.XposedBridge;

final class Overlay {
    private static final String TAG = "UnlockPop: ";
    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static Context appCtx;
    private static boolean inited;
    private static PopView view;
    private static long last;

    private Overlay() {}

    static void init(Context ctx) {
        if (inited) return;
        inited = true;
        appCtx = ctx;
        BroadcastReceiver r = new BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent i) {
                play(i == null ? null : i.getStringExtra("type"));
            }
        };
        ctx.registerReceiver(r, new IntentFilter(MainHook.ACTION), Context.RECEIVER_EXPORTED);
        XposedBridge.log(TAG + "overlay receiver ready");
    }

    private static Context ctx() {
        if (appCtx != null) return appCtx;
        try {
            Class<?> at = Class.forName("android.app.ActivityThread");
            Object app = at.getMethod("currentApplication").invoke(null);
            if (app instanceof Context) appCtx = (Context) app;
        } catch (Throwable ignored) {
        }
        return appCtx;
    }

    static void play(final String type) {
        MAIN.post(new Runnable() {
            @Override
            public void run() {
                try {
                    show("face".equals(type) ? 0 : 1);
                } catch (Throwable t) {
                    XposedBridge.log(TAG + "show failed: " + t);
                    view = null;
                }
            }
        });
    }

    private static void show(int mode) {
        long now = SystemClock.uptimeMillis();
        if (view != null || now - last < 800) return;
        Context c = ctx();
        if (c == null) return;
        last = now;
        final WindowManager wm = (WindowManager) c.getSystemService(Context.WINDOW_SERVICE);
        final PopView v = new PopView(c, mode);
        int flags = WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS
                | WindowManager.LayoutParams.FLAG_HARDWARE_ACCELERATED;
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.MATCH_PARENT, v.windowHeight(), 2024, flags, PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.TOP | Gravity.CENTER_HORIZONTAL;
        lp.layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
        lp.setTitle("UnlockPop");
        try {
            wm.addView(v, lp);
        } catch (Throwable t) {
            lp.type = 2010;
            wm.addView(v, lp);
        }
        view = v;
        v.start(new Runnable() {
            @Override
            public void run() {
                try {
                    wm.removeViewImmediate(v);
                } catch (Throwable ignored) {
                }
                view = null;
            }
        });
    }
}
