package dev.bonu.unlockpop;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends Activity {
    private SharedPreferences sp;
    private float density;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("cfg", MODE_PRIVATE);
        density = getResources().getDisplayMetrics().density;
        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = (int) (24 * density);
        root.setPadding(p, p * 2, p, p);
        sv.addView(root);

        TextView tv = new TextView(this);
        tv.setTextSize(16);
        tv.setText("Unlock Pop\n\nEnable this module in Vector with System Framework and System UI ticked "
                + "in its scope, then soft reboot. Changes below apply straight away.\n");
        root.addView(tv);

        root.addView(sw("Face and fingerprint animation", "unlock"));
        root.addView(sw("Bluetooth pop-up", "bt"));
        root.addView(sw("Wired headset pop-up", "wired"));

        TextView ct = new TextView(this);
        ct.setTextSize(16);
        ct.setPadding(0, dp(18), 0, dp(4));
        ct.setText("Animation color");
        root.addView(ct);
        RadioGroup rg = new RadioGroup(this);
        rg.setOrientation(RadioGroup.HORIZONTAL);
        final RadioButton rb = new RadioButton(this);
        rb.setText("Blue");
        rb.setId(View.generateViewId());
        final RadioButton rgn = new RadioButton(this);
        rgn.setText("Green");
        rgn.setId(View.generateViewId());
        rg.addView(rb);
        rg.addView(rgn);
        if ("green".equals(sp.getString("color", "blue"))) rgn.setChecked(true);
        else rb.setChecked(true);
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup g, int id) {
                sp.edit().putString("color", id == rgn.getId() ? "green" : "blue").apply();
                notifyCfg();
            }
        });
        root.addView(rg);

        TextView tt = new TextView(this);
        tt.setTextSize(16);
        tt.setPadding(0, dp(18), 0, dp(4));
        tt.setText("Test (plays on screen without unlocking)");
        root.addView(tt);
        root.addView(test("Test face unlock", "face", 0, null));
        root.addView(test("Test fingerprint", "finger", 0, null));
        root.addView(test("Test Bluetooth earbuds", "bt", 0, "Test earbuds"));
        root.addView(test("Test wired headset", "wired", 2, "Wired headset"));
        setContentView(sv);
    }

    private int dp(int v) {
        return (int) (v * density);
    }

    private Switch sw(String label, final String key) {
        Switch s = new Switch(this);
        s.setText(label);
        s.setChecked(sp.getBoolean(key, true));
        s.setPadding(0, dp(10), 0, dp(10));
        s.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton v, boolean on) {
                sp.edit().putBoolean(key, on).apply();
                notifyCfg();
            }
        });
        return s;
    }

    private void notifyCfg() {
        sendBroadcast(new Intent(MainHook.ACTION_CFG).setPackage("com.android.systemui"));
    }

    private Button test(String label, final String type, final int kind, final String text) {
        Button bt = new Button(this);
        bt.setText(label);
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendBroadcast(new Intent(MainHook.ACTION)
                        .setPackage("com.android.systemui")
                        .putExtra("type", type)
                        .putExtra("kind", kind)
                        .putExtra("label", text)
                        .putExtra("test", true));
            }
        });
        return bt;
    }
}
