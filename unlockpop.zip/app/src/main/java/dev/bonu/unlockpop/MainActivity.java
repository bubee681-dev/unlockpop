package dev.bonu.unlockpop;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = (int) (24 * getResources().getDisplayMetrics().density);
        root.setPadding(p, p * 2, p, p);
        TextView tv = new TextView(this);
        tv.setTextSize(16);
        tv.setText("Unlock Pop\n\nEnable this module in Vector, tick System Framework and System UI in its scope, "
                + "then soft reboot. The buttons below play the animation on the screen without unlocking, "
                + "so you can check its position and size.\n");
        root.addView(tv);
        root.addView(button("Test face unlock", "face"));
        root.addView(button("Test fingerprint", "finger"));
        setContentView(root);
    }

    private Button button(String label, final String type) {
        Button bt = new Button(this);
        bt.setText(label);
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendBroadcast(new Intent(MainHook.ACTION)
                        .setPackage("com.android.systemui")
                        .putExtra("type", type));
            }
        });
        return bt;
    }
}
