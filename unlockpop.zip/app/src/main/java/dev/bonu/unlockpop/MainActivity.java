package dev.bonu.unlockpop;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Switch;
import android.widget.TextView;

public class MainActivity extends Activity {
    private SharedPreferences sp;
    private float density;

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences("cfg", MODE_PRIVATE);
        density = getResources().getDisplayMetrics().density;
        ScrollView sv = new ScrollView(this);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        int p = (int) (24 * density);
        root.setPadding(p, p * 2, p, p);
        sv.addView(root);

        TextView tv = new TextView(this);
        tv.setTextSize(16);
        tv.setText("Unlock Pop\n\nEnable this module in Vector with System Framework and System UI ticked "
                + "in its scope, then soft reboot. Changes below apply straight away.\n");
        root.addView(tv);

        root.addView(sw("Face and fingerprint animation", "unlock"));
        root.addView(sw("Bluetooth pop-up", "bt"));
        root.addView(sw("Wired headset pop-up", "wired"));
        root.addView(sw("Call card (incoming and ongoing calls)", "calls"));
        root.addView(sw("Three-dot camera look (always on)", "dots"));
        root.addView(sw("Live dot: call (right dot turns green and pulses)", "lcall"));
        root.addView(sw("Live dot: music (left dot shows moving bars)", "lmusic"));
        root.addView(sw("Live dot: timer (countdown ring around left dot)", "ltimer"));
        root.addView(sw("Live dots (call, music, timer)", "live"));
        RadioGroup lg = new RadioGroup(this);
        lg.setOrientation(RadioGroup.VERTICAL);
        final RadioButton l0 = new RadioButton(this);
        l0.setText("One dot on each side");
        l0.setId(View.generateViewId());
        final RadioButton l1 = new RadioButton(this);
        l1.setText("Both dots on the left");
        l1.setId(View.generateViewId());
        final RadioButton l2 = new RadioButton(this);
        l2.setText("Both dots on the right");
        l2.setId(View.generateViewId());
        lg.addView(l0);
        lg.addView(l1);
        lg.addView(l2);
        String cur = sp.getString("layout", "split");
        if ("left".equals(cur)) l1.setChecked(true);
        else if ("right".equals(cur)) l2.setChecked(true);
        else l0.setChecked(true);
        lg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup g, int id) {
                String v = id == l1.getId() ? "left" : (id == l2.getId() ? "right" : "split");
                sp.edit().putString("layout", v).apply();
                notifyCfg();
            }
        });
        root.addView(lg);
        final TextView xl = new TextView(this);
        final TextView yl = new TextView(this);
        final SeekBar xs = new SeekBar(this);
        final SeekBar ys = new SeekBar(this);
        xs.setMax(80);
        ys.setMax(80);
        xs.setProgress(sp.getInt("dx2", 0) + 40);
        ys.setProgress(sp.getInt("dy2", 9) + 40);
        xl.setText(label("Dots left / right", sp.getInt("dx2", 0)));
        yl.setText(label("Dots up / down", sp.getInt("dy2", 9)));
        xl.setPadding(0, dp(14), 0, 0);
        yl.setPadding(0, dp(14), 0, 0);
        xs.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                int v = progress - 40;
                xl.setText(label("Dots left / right", v));
                if (fromUser) {
                    sp.edit().putInt("dx2", v).apply();
                    notifyCfg();
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
            }
        });
        ys.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar bar, int progress, boolean fromUser) {
                int v = progress - 40;
                yl.setText(label("Dots up / down", v));
                if (fromUser) {
                    sp.edit().putInt("dy2", v).apply();
                    notifyCfg();
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar bar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar bar) {
            }
        });
        Button reset = new Button(this);
        reset.setText("Reset dot position");
        reset.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sp.edit().putInt("dx2", 0).putInt("dy2", 9).apply();
                xs.setProgress(40);
                ys.setProgress(49);
                notifyCfg();
            }
        });
        root.addView(xl);
        root.addView(xs);
        root.addView(yl);
        root.addView(ys);
        root.addView(reset);

        TextView ct = new TextView(this);
        ct.setTextSize(16);
        ct.setPadding(0, dp(18), 0, dp(4));
        ct.setText("Animation color");
        root.addView(ct);
        RadioGroup rg = new RadioGroup(this);
        rg.setOrientation(RadioGroup.HORIZONTAL);
        final RadioButton rb = new RadioButton(this);
        rb.setText("Blue");
        rb.setId(View.generateViewId());
        final RadioButton rgn = new RadioButton(this);
        rgn.setText("Green");
        rgn.setId(View.generateViewId());
        rg.addView(rb);
        rg.addView(rgn);
        if ("green".equals(sp.getString("color", "blue"))) rgn.setChecked(true);
        else rb.setChecked(true);
        rg.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup g, int id) {
                sp.edit().putString("color", id == rgn.getId() ? "green" : "blue").apply();
                notifyCfg();
            }
        });
        root.addView(rg);

        TextView tt = new TextView(this);
        tt.setTextSize(16);
        tt.setPadding(0, dp(18), 0, dp(4));
        tt.setText("Test (plays on screen without unlocking)");
        root.addView(tt);
        root.addView(test("Test face unlock", "face", 0, null));
        root.addView(test("Test fingerprint", "finger", 0, null));
        root.addView(test("Test Bluetooth earbuds", "bt", 0, "Test earbuds"));
        root.addView(test("Test wired headset", "wired", 2, "Wired headset"));
        root.addView(test("Test call card", "calltest", 0, null));
        root.addView(test("Test live dots (8 seconds)", "livetest", 0, null));
        setContentView(sv);
    }

    private static String label(String name, int half) {
        float v = half / 2f;
        return name + ": " + (v > 0 ? "+" : "") + v + " dp";
    }

    private int dp(int v) {
        return (int) (v * density);
    }

    private Switch sw(String label, final String key) {
        Switch s = new Switch(this);
        s.setText(label);
        s.setChecked(sp.getBoolean(key, true));
        s.setPadding(0, dp(10), 0, dp(10));
        s.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton v, boolean on) {
                sp.edit().putBoolean(key, on).apply();
                notifyCfg();
            }
        });
        return s;
    }

    private void notifyCfg() {
        sendBroadcast(new Intent(MainHook.ACTION_CFG).setPackage("com.android.systemui"));
    }

    private Button test(String label, final String type, final int kind, final String text) {
        Button bt = new Button(this);
        bt.setText(label);
        bt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                sendBroadcast(new Intent(MainHook.ACTION)
                        .setPackage("com.android.systemui")
                        .putExtra("type", type)
                        .putExtra("kind", kind)
                        .putExtra("label", text)
                        .putExtra("test", true));
            }
        });
        return bt;
    }
}
