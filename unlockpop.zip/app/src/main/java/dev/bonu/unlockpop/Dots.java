package dev.bonu.unlockpop;

import android.graphics.Canvas;
import android.graphics.Paint;

/** The two extra black dots beside the camera hole. Layout: 0 one each side, 1 both left, 2 both right. */
final class Dots {
    private Dots() {}

    /** Returns {x0, y0, x1, y1}: centers of the first and second dot. */
    static float[] centers(float cx, float cy, float r0, int layout, float dxPx, float dyPx) {
        float step = 2.9f * r0;
        float a, b;
        if (layout == 1) {
            a = -step;
            b = -2f * step;
        } else if (layout == 2) {
            a = step;
            b = 2f * step;
        } else {
            a = -step;
            b = step;
        }
        return new float[]{cx + a + dxPx, cy + dyPx, cx + b + dxPx, cy + dyPx};
    }

    static float[] offsets(int layout, float r0) {
        float step = 2.9f * r0;
        if (layout == 1) return new float[]{-step, -2f * step};
        if (layout == 2) return new float[]{step, 2f * step};
        return new float[]{-step, step};
    }

    static void draw(Canvas c, Paint p, float cx, float cy, float r0, int layout, float frac, float radScale, float dxPx, float dyPx) {
        float[] o = offsets(layout, r0);
        float rad = Math.max(0.5f, r0 * 0.92f * radScale);
        for (float d : o) c.drawCircle(cx + (d + dxPx) * frac, cy + dyPx * frac, rad, p);
    }
}
