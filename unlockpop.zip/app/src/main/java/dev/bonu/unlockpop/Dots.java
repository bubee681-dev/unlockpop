package dev.bonu.unlockpop;

import android.graphics.Canvas;
import android.graphics.Paint;

/** The two extra black dots beside the camera hole. Layout: 0 one each side, 1 both left, 2 both right. */
final class Dots {
    private Dots() {}

    static void draw(Canvas c, Paint p, float cx, float cy, float r0, int layout, float frac, float radScale) {
        float step = 2.9f * r0;
        float[] o;
        if (layout == 1) o = new float[]{-step, -2f * step};
        else if (layout == 2) o = new float[]{step, 2f * step};
        else o = new float[]{-step, step};
        float rad = Math.max(0.5f, r0 * 0.92f * radScale);
        for (float d : o) c.drawCircle(cx + d * frac, cy, rad, p);
    }
}
