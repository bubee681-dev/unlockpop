package dev.bonu.unlockpop;

/** States shown by the live dots. Written on the main thread in System UI. */
final class Live {
    static volatile boolean call, music;
    static volatile long timerEnd, timerTotal;
    static volatile String timerPkg;

    private Live() {}

    static void clearTimer() {
        timerEnd = 0;
        timerTotal = 0;
        timerPkg = null;
    }
}
