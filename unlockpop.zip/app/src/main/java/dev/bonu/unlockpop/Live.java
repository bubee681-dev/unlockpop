package dev.bonu.unlockpop;

/** States shown by the live dots. Written on the main thread in System UI. */
final class Live {
    /** 0 none, 1 ringing, 2 in a call. */
    static volatile int call;
    static volatile boolean music;
    static volatile long timerStart, timerEnd;

    private Live() {}

    static boolean timerOn() {
        return timerEnd > System.currentTimeMillis();
    }

    static float timerFrac() {
        long now = System.currentTimeMillis();
        long total = timerEnd - timerStart;
        if (total <= 0L || now >= timerEnd) return 0f;
        float f = (timerEnd - now) / (float) total;
        return f < 0f ? 0f : (f > 1f ? 1f : f);
    }

    static boolean active() {
        return Config.live && (call != 0 || music || timerOn());
    }
}
