package dev.bonu.unlockpop;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

/** Settings as seen from System UI. Read from the module app through CfgProvider. */
final class Config {
    static volatile boolean unlock = true;
    static volatile boolean bt = true;
    static volatile boolean wired = true;
    static volatile boolean green = false;
    static volatile boolean dots = false;
    static volatile boolean calls = false;
    static volatile boolean liveCall = false;
    static volatile boolean liveMusic = false;
    static volatile boolean liveTimer = false;
    static volatile boolean live = false;
    static volatile int layout = 0;
    static volatile float dotDx = 0f;
    static volatile float dotDy = 4.5f;

    private Config() {}

    static void refresh(final Context c) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Bundle b = c.getContentResolver().call(Uri.parse("content://dev.bonu.unlockpop.cfg"), "get", null, null);
                    if (b == null) return;
                    unlock = b.getBoolean("unlock", true);
                    bt = b.getBoolean("bt", true);
                    wired = b.getBoolean("wired", true);
                    green = b.getBoolean("green", false);
                    dots = b.getBoolean("dots", false);
                    calls = b.getBoolean("calls", false);
                    liveCall = b.getBoolean("lcall", false);
                    liveMusic = b.getBoolean("lmusic", false);
                    liveTimer = b.getBoolean("ltimer", false);
                    live = b.getBoolean("live", false);
                    layout = b.getInt("layout", 0);
                    dotDx = b.getFloat("dx", 0f);
                    dotDy = b.getFloat("dy", 4.5f);
                    Overlay.syncDots();
                } catch (Throwable ignored) {
                }
            }
        }).start();
    }
}
