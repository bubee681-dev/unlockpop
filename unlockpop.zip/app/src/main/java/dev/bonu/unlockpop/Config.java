package dev.bonu.unlockpop;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;

/** Settings as seen from System UI. Read from the module app through CfgProvider. */
final class Config {
    static volatile boolean unlock = true;
    static volatile boolean bt = true;
    static volatile boolean wired = true;
    static volatile boolean green = false;

    private Config() {}

    static void refresh(final Context c) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    Bundle b = c.getContentResolver().call(Uri.parse("content://dev.bonu.unlockpop.cfg"), "get", null, null);
                    if (b == null) return;
                    unlock = b.getBoolean("unlock", true);
                    bt = b.getBoolean("bt", true);
                    wired = b.getBoolean("wired", true);
                    green = b.getBoolean("green", false);
                } catch (Throwable ignored) {
                }
            }
        }).start();
    }
}
