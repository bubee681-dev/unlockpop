package dev.bonu.unlockpop;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.SystemClock;
import android.graphics.RectF;
import android.os.SystemClock;
import android.view.DisplayCutout;
import android.view.View;
import android.view.WindowInsets;

import java.util.List;

/** Always-on layer that draws the two dots beside the camera hole. */
public class DotsView extends View {
    private final Paint black = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float dp;
    private final Paint live = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF tmpR = new RectF();
    private boolean found;
    private float cx, cy, r0;

    public DotsView(Context c) {
        super(c);
        dp = c.getResources().getDisplayMetrics().density;
        black.setStyle(Paint.Style.FILL);
        black.setColor(0xFF000000);
        cy = dp * 20f;
        r0 = dp * 10f;
    }

    int windowHeight() {
        return (int) (dp * 72f);
    }

    @Override
    public WindowInsets onApplyWindowInsets(WindowInsets insets) {
        found = false;
        invalidate();
        return super.onApplyWindowInsets(insets);
    }

    private void measureHole() {
        if (found) return;
        cx = getWidth() / 2f;
        try {
            WindowInsets wi = getRootWindowInsets();
            DisplayCutout dc = wi == null ? null : wi.getDisplayCutout();
            if (dc != null) {
                List<Rect> rs = dc.getBoundingRects();
                Rect best = null;
                for (Rect r : rs) {
                    if (best == null || r.top < best.top) best = r;
                }
                if (best != null) {
                    cx = best.exactCenterX();
                    cy = best.exactCenterY();
                    r0 = Math.min(best.width(), best.height()) / 2f;
                    found = true;
                }
            }
        } catch (Throwable ignored) {
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) return;
        measureHole();
        Dots.draw(c, black, cx, cy, r0, Config.layout, 1f, 1f, Config.dotDx * dp, Config.dotDy * dp);
        if (Live.active()) {
            drawLive(c);
            postInvalidateOnAnimation();
        }
    }

    private static int al(float x) {
        return (int) (255f * (x < 0f ? 0f : (x > 1f ? 1f : x)));
    }

    private void drawLive(Canvas c) {
        float[] p = Dots.centers(cx, cy, r0, Config.layout, Config.dotDx * dp, Config.dotDy * dp);
        float rad = r0 * 0.92f;
        long now = SystemClock.uptimeMillis();
        int accent = Config.green ? PopView.GREEN : PopView.BLUE;

        // call: right dot turns green and pulses
        if (Live.call != 0) {
            float per = Live.call == 1 ? 700f : 1800f;
            float ph = (now % (long) per) / per;
            float pul = 0.5f + 0.5f * (float) Math.sin(ph * 2.0 * Math.PI);
            live.setStyle(Paint.Style.FILL);
            live.setColor(0xFF30D158);
            live.setAlpha(al(0.55f + 0.45f * pul));
            c.drawCircle(p[2], p[3], rad * (0.38f + 0.12f * pul), live);
            if (Live.call == 1) {
                live.setStyle(Paint.Style.STROKE);
                live.setStrokeWidth(rad * 0.12f);
                live.setAlpha(al(0.7f * (1f - ph)));
                c.drawCircle(p[2], p[3], rad * (0.5f + 0.4f * ph), live);
            }
        }

        // timer ring around the left dot
        boolean timer = Live.timerOn();
        if (timer) {
            live.setStyle(Paint.Style.STROKE);
            live.setColor(accent);
            live.setStrokeCap(Paint.Cap.ROUND);
            live.setStrokeWidth(rad * 0.2f);
            live.setAlpha(255);
            float rr = rad * 0.78f;
            tmpR.set(p[0] - rr, p[1] - rr, p[0] + rr, p[1] + rr);
            c.drawArc(tmpR, -90f, 360f * Live.timerFrac(), false, live);
        }

        // music bars inside the left dot
        if (Live.music) {
            live.setStyle(Paint.Style.FILL);
            live.setColor(accent);
            live.setAlpha(255);
            float k = timer ? 0.7f : 1f;
            float bw = rad * 0.26f * k;
            float gap = rad * 0.15f * k;
            float x0 = p[0] - (3f * bw + 2f * gap) / 2f;
            for (int i = 0; i < 3; i++) {
                float hgt = rad * k * (0.30f + 0.55f * (0.5f + 0.5f * (float) Math.sin(now / 180.0 + i * 2.1)));
                float x = x0 + i * (bw + gap);
                c.drawRoundRect(x, p[1] - hgt / 2f, x + bw, p[1] + hgt / 2f, bw / 2f, bw / 2f, live);
            }
        }
    }
}
