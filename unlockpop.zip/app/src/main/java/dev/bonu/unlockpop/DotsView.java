package dev.bonu.unlockpop;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.view.DisplayCutout;
import android.view.View;
import android.view.WindowInsets;

import java.util.List;

/** Always-on layer that draws the two dots beside the camera hole. */
public class DotsView extends View {
    private final Paint black = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final float dp;
    private boolean found;
    private float cx, cy, r0;

    public DotsView(Context c) {
        super(c);
        dp = c.getResources().getDisplayMetrics().density;
        black.setStyle(Paint.Style.FILL);
        black.setColor(0xFF000000);
        cy = dp * 20f;
        r0 = dp * 10f;
    }

    int windowHeight() {
        return (int) (dp * 48f);
    }

    @Override
    public WindowInsets onApplyWindowInsets(WindowInsets insets) {
        found = false;
        invalidate();
        return super.onApplyWindowInsets(insets);
    }

    private void measureHole() {
        if (found) return;
        cx = getWidth() / 2f;
        try {
            WindowInsets wi = getRootWindowInsets();
            DisplayCutout dc = wi == null ? null : wi.getDisplayCutout();
            if (dc != null) {
                List<Rect> rs = dc.getBoundingRects();
                Rect best = null;
                for (Rect r : rs) {
                    if (best == null || r.top < best.top) best = r;
                }
                if (best != null) {
                    cx = best.exactCenterX();
                    cy = best.exactCenterY();
                    r0 = Math.min(best.width(), best.height()) / 2f;
                    found = true;
                }
            }
        } catch (Throwable ignored) {
        }
    }

    @Override
    protected void onDraw(Canvas c) {
        if (getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE) return;
        measureHole();
        Dots.draw(c, black, cx, cy, r0, Config.layout, 1f, 1f);
    }
}
