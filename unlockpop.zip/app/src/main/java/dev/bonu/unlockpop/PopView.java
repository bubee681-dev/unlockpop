package dev.bonu.unlockpop;

import android.bluetooth.BluetoothClass;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.Rect;
import android.graphics.RectF;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.Choreographer;
import android.view.DisplayCutout;
import android.view.View;
import android.view.WindowInsets;

import java.util.List;

public class PopView extends View {
    static final int BLUE = 0xFF378ADD;
    static final int GREEN = 0xFF34C759;
    private static final float SPEED = 1.1f;

    private static final class Part {
        final Path p;
        final PathMeasure pm;
        final float len, cx, cy;

        Part(Path path) {
            p = path;
            pm = new PathMeasure(path, false);
            len = pm.getLength();
            RectF r = new RectF();
            path.computeBounds(r, true);
            cx = r.centerX();
            cy = r.centerY();
        }
    }

    private final int mode;   // 0 face, 1 fingerprint, 2 device card
    private final String label;
    private final float dp;
    private float exitAt;
    private float total;
    private final Paint blue = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint black = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint text = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final Path seg = new Path();
    private final Path ell = new Path();
    private final RectF tmp = new RectF();
    private final RectF arcRect = new RectF(54, 54, 146, 146);
    private Part[] brk, face, fp, icon;
    private Part tick;

    private float t;
    private boolean found;
    private float cx, cy, r0;
    private Runnable endCb;

    private final Choreographer.FrameCallback ticker = new Choreographer.FrameCallback() {
        private long last;

        @Override
        public void doFrame(long ns) {
            if (last != 0) {
                float dt = (ns - last) / 1000000f;
                if (dt > 26f) dt = 26f;   // a hitch must not skip animation phases
                t += dt * SPEED;
            }
            last = ns;
            if (t >= total) {
                if (endCb != null) endCb.run();
                return;
            }
            invalidate();
            Choreographer.getInstance().postFrameCallback(this);
        }
    };

    public PopView(Context c, int mode, int color, int kind, String label) {
        super(c);
        this.mode = mode;
        this.label = label == null ? "" : label;
        this.dp = c.getResources().getDisplayMetrics().density;
        this.exitAt = mode == 2 ? 2300f : 2050f;
        this.total = exitAt + 400f;
        blue.setStyle(Paint.Style.STROKE);
        blue.setColor(color);
        blue.setStrokeWidth(6.5f);
        blue.setStrokeCap(Paint.Cap.ROUND);
        blue.setStrokeJoin(Paint.Join.ROUND);
        black.setStyle(Paint.Style.FILL);
        black.setColor(0xFF000000);
        text.setColor(0xFFFFFFFF);
        text.setTextSize(dp * 12.5f);
        text.setTextAlign(Paint.Align.CENTER);
        buildParts();
        if (mode == 2) icon = parts(iconPaths(kind));
        cx = 0f;
        cy = dp * 20f;
        r0 = dp * 10f;
    }

    int windowHeight() {
        return (int) (dp * 160f);
    }

    void start(Runnable end) {
        endCb = end;
        Choreographer.getInstance().postFrameCallback(ticker);
    }

    /** Returns icon kind for a Bluetooth device, or -1 to ignore it (watches, bands and so on). */
    static int classify(String name, BluetoothClass bc) {
        String n = name == null ? "" : name.toLowerCase();
        if (has(n, "buds", "pods", "airdots", "earbud", "tws", "earphone")) return 0;
        if (has(n, "headphone", "over-ear")) return 1;
        if (has(n, "headset", "hfp")) return 2;
        if (has(n, "speaker", "boom", "soundbar", "flip")) return 3;
        if (bc != null) {
            int dc = bc.getDeviceClass();
            if (dc == BluetoothClass.Device.AUDIO_VIDEO_HEADPHONES) return 1;
            if (dc == BluetoothClass.Device.AUDIO_VIDEO_WEARABLE_HEADSET
                    || dc == BluetoothClass.Device.AUDIO_VIDEO_HANDSFREE) return 2;
            if (dc == BluetoothClass.Device.AUDIO_VIDEO_LOUDSPEAKER
                    || dc == BluetoothClass.Device.AUDIO_VIDEO_PORTABLE_AUDIO
                    || dc == BluetoothClass.Device.AUDIO_VIDEO_HIFI_AUDIO) return 3;
            if (dc == BluetoothClass.Device.AUDIO_VIDEO_CAR_AUDIO) return 4;
            if (bc.getMajorDeviceClass() == BluetoothClass.Device.Major.AUDIO_VIDEO) return 2;
        }
        return -1;
    }

    private static boolean has(String n, String... keys) {
        for (String k : keys) if (n.contains(k)) return true;
        return false;
    }

    private static Path line(float x1, float y1, float x2, float y2) {
        Path p = new Path();
        p.moveTo(x1, y1);
        p.lineTo(x2, y2);
        return p;
    }

    private static Part[] parts(Path[] ps) {
        Part[] r = new Part[ps.length];
        for (int i = 0; i < ps.length; i++) r[i] = new Part(ps[i]);
        return r;
    }

    private static Path[] iconPaths(int kind) {
        Path band = new Path();
        band.moveTo(52, 104); band.lineTo(52, 94); band.arcTo(new RectF(52, 46, 148, 142), 180, 180, false); band.lineTo(148, 104);
        Path lc = new Path();
        lc.addRoundRect(new RectF(44, 100, 72, 148), 10, 10, Path.Direction.CW);
        Path rc = new Path();
        rc.addRoundRect(new RectF(128, 100, 156, 148), 10, 10, Path.Direction.CW);
        switch (kind) {
            case 0: {
                Path a = new Path();
                a.addCircle(68, 88, 17, Path.Direction.CW);
                Path b = new Path();
                b.addCircle(132, 88, 17, Path.Direction.CW);
                return new Path[]{a, line(80, 100, 80, 150), b, line(120, 100, 120, 150)};
            }
            case 1:
                return new Path[]{band, lc, rc};
            case 2: {
                Path boom = new Path();
                boom.moveTo(56, 148); boom.quadTo(60, 172, 90, 174); boom.lineTo(104, 174);
                return new Path[]{band, lc, rc, boom};
            }
            case 3: {
                Path body = new Path();
                body.addRoundRect(new RectF(66, 48, 134, 152), 16, 16, Path.Direction.CW);
                Path woofer = new Path();
                woofer.addCircle(100, 116, 20, Path.Direction.CW);
                Path tweeter = new Path();
                tweeter.addCircle(100, 78, 7, Path.Direction.CW);
                return new Path[]{body, woofer, tweeter};
            }
            default: {
                Path r = new Path();
                r.moveTo(78, 80); r.lineTo(122, 120); r.lineTo(100, 144); r.lineTo(100, 56); r.lineTo(122, 80); r.lineTo(78, 120);
                return new Path[]{r};
            }
        }
    }

    private void buildParts() {
        Path[] b = new Path[4];
        b[0] = new Path();
        b[0].moveTo(52, 78); b[0].lineTo(52, 62); b[0].arcTo(new RectF(52, 52, 72, 72), 180, 90, false); b[0].lineTo(78, 52);
        b[1] = new Path();
        b[1].moveTo(148, 78); b[1].lineTo(148, 62); b[1].arcTo(new RectF(128, 52, 148, 72), 0, -90, false); b[1].lineTo(122, 52);
        b[2] = new Path();
        b[2].moveTo(52, 122); b[2].lineTo(52, 138); b[2].arcTo(new RectF(52, 128, 72, 148), 180, -90, false); b[2].lineTo(78, 148);
        b[3] = new Path();
        b[3].moveTo(148, 122); b[3].lineTo(148, 138); b[3].arcTo(new RectF(128, 128, 148, 148), 0, 90, false); b[3].lineTo(122, 148);
        brk = parts(b);

        Path nose = new Path();
        nose.moveTo(100, 88); nose.lineTo(100, 112); nose.quadTo(100, 118, 93, 118);
        Path mouth = new Path();
        mouth.moveTo(82, 130); mouth.quadTo(100, 144, 118, 130);
        face = parts(new Path[]{line(80, 84, 80, 98), line(120, 84, 120, 98), nose, mouth});

        Path[] f = new Path[9];
        f[0] = new Path();
        f[0].moveTo(48, 118); f[0].lineTo(48, 96); f[0].arcTo(new RectF(48, 44, 152, 148), 180, 180, false); f[0].lineTo(152, 106);
        f[1] = new Path();
        f[1].moveTo(60, 138); f[1].lineTo(60, 98); f[1].arcTo(new RectF(60, 58, 140, 138), 180, 180, false); f[1].lineTo(140, 132);
        f[2] = new Path();
        f[2].moveTo(72, 150); f[2].lineTo(72, 100); f[2].arcTo(new RectF(72, 72, 128, 128), 180, 180, false); f[2].lineTo(128, 142);
        f[3] = new Path();
        f[3].moveTo(84, 160); f[3].lineTo(84, 102); f[3].arcTo(new RectF(84, 86, 116, 118), 180, 180, false); f[3].lineTo(116, 152);
        f[4] = line(100, 114, 100, 168);
        f[5] = new Path(); f[5].moveTo(48, 130); f[5].quadTo(48, 152, 62, 168);
        f[6] = new Path(); f[6].moveTo(152, 120); f[6].quadTo(152, 148, 138, 166);
        f[7] = new Path(); f[7].moveTo(66, 152); f[7].quadTo(70, 166, 80, 174);
        f[8] = new Path(); f[8].moveTo(134, 160); f[8].quadTo(130, 170, 124, 176);
        fp = parts(f);

        Path tk = new Path();
        tk.moveTo(80, 102); tk.lineTo(94, 116); tk.lineTo(121, 86);
        tick = new Part(tk);
    }

    private void measureHole() {
        if (found) return;
        cx = getWidth() / 2f;
        try {
            WindowInsets wi = getRootWindowInsets();
            DisplayCutout dc = wi == null ? null : wi.getDisplayCutout();
            if (dc != null) {
                List<Rect> rs = dc.getBoundingRects();
                Rect best = null;
                for (Rect r : rs) {
                    if (best == null || r.top < best.top) best = r;
                }
                if (best != null) {
                    cx = best.exactCenterX();
                    cy = best.exactCenterY();
                    r0 = Math.min(best.width(), best.height()) / 2f;
                    found = true;
                }
            }
        } catch (Throwable ignored) {
        }
    }

    private static float clamp(float x) {
        return x < 0f ? 0f : (x > 1f ? 1f : x);
    }

    private static float lerp(float a, float b, float k) {
        return a + (b - a) * k;
    }

    private static float ease(float x) {
        return x * x * (3f - 2f * x);
    }

    private static float spring(float x) {
        x = clamp(x);
        return 1f - (float) (Math.exp(-6.5 * x) * Math.cos(3.0 * Math.PI * x));
    }

    private static int a(float x) {
        return (int) (255f * clamp(x));
    }

    private void drawGlow(Canvas c, Path path, float w, float alpha, float blur) {
        if (blur > 0.6f) {
            for (int k = 3; k >= 1; k--) {
                blue.setAlpha(a(alpha * 0.16f));
                blue.setStrokeWidth(w + blur * k * 0.9f);
                c.drawPath(path, blue);
            }
            alpha = alpha * (1f - Math.min(1f, blur / 12f) * 0.55f);
        }
        blue.setAlpha(a(alpha));
        blue.setStrokeWidth(w);
        c.drawPath(path, blue);
    }

    private void strokePart(Canvas c, Part o, float f, float w, float alpha, float blur) {
        if (alpha <= 0.01f || f <= 0f) return;
        Path path = o.p;
        if (f < 1f) {
            seg.reset();
            o.pm.getSegment(0f, o.len * f, seg, true);
            path = seg;
        }
        drawGlow(c, path, w, alpha, blur);
    }

    @Override
    protected void onDraw(Canvas c) {
        if (!found && t < 250f) measureHole();
        float w = dp * 118f;
        float h = dp * 118f;
        float rad0 = dp * 32f;
        float rr = r0 + dp * 1.5f;
        float gw, gh, rad, k;
        if (t < 100f) {
            k = ease(t / 100f);
            gw = lerp(2f * rr, 3.4f * rr, k);
            gh = 2f * rr;
            rad = rr;
        } else if (t < 400f) {
            k = spring((t - 100f) / 300f);
            gw = lerp(3.4f * rr, w, k);
            gh = lerp(2f * rr, h, k);
            rad = lerp(rr, rad0, k);
        } else if (t < exitAt) {
            gw = w;
            gh = h;
            rad = rad0;
        } else if (t < exitAt + 120f) {
            k = ease((t - exitAt) / 120f);
            gw = lerp(w, w * 1.06f, k);
            gh = lerp(h, h * 0.55f, k);
            rad = lerp(rad0, rad0 * 0.7f, k);
        } else {
            k = clamp((t - exitAt - 120f) / 280f);
            float k3 = k * k * k;
            gw = lerp(w * 1.06f, 2f * rr, k3);
            gh = lerp(h * 0.55f, 2f * rr, k3);
            rad = lerp(rad0 * 0.7f, rr, k3);
        }
        float top = Math.max(0f, cy - rr);
        rad = Math.max(0f, Math.min(rad, Math.min(gw, gh) / 2f));
        c.drawRoundRect(cx - gw / 2f, top, cx + gw / 2f, top + gh, rad, rad, black);
        float ti = t - 180f;
        if (ti < 0f) return;
        float vis = clamp((t - 200f) / 150f) * (1f - clamp((t - exitAt) / 120f));
        if (vis <= 0f) return;
        if (mode == 2) drawCard(c, top, w, h, ti, vis);
        else drawIcon(c, cx, top + h * 0.56f, ti, vis);
    }

    private void drawCard(Canvas c, float top, float w, float h, float ti, float vis) {
        c.save();
        c.translate(cx, top + h * 0.45f);
        float s = dp * 104f / 200f;
        c.scale(s, s);
        c.translate(-100f, -100f);
        for (int i = 0; i < icon.length; i++) {
            strokePart(c, icon[i], clamp((ti - i * 70f) / 350f), 6.5f, vis, 0f);
        }
        c.restore();
        float al = clamp((ti - 250f) / 250f) * vis;
        if (al > 0f) {
            text.setAlpha(a(al));
            String s2 = TextUtils.ellipsize(label, text, w * 0.82f, TextUtils.TruncateAt.END).toString();
            c.drawText(s2, cx, top + h * 0.90f, text);
        }
    }

    private void drawIcon(Canvas c, float x, float y, float ti, float vis) {
        boolean isFp = mode == 1;
        c.save();
        c.translate(x, y);
        float s = dp * 118f / 200f;
        c.scale(s, s);
        float pw = clamp((ti - 770f) / 300f);
        float mx = 100f, my = isFp ? 110f : 100f;

        c.save();
        if (isFp) {
            c.scale(0.78f, 0.78f);
            c.translate(-100f, -110f);
        } else {
            c.translate(-100f, -100f);
        }
        if (!isFp) {
            float ba = clamp(ti / 250f) * (1f - clamp(pw * 1.4f)) * vis;
            float sc0 = 1f - 0.1f * (float) Math.sin(Math.PI * clamp(ti / 450f));
            c.save();
            c.translate(100f, 100f);
            c.scale(sc0, sc0);
            c.translate(-100f, -100f);
            for (Part b : brk) strokePart(c, b, 1f, 6.5f, ba, 0f);
            c.restore();
        }
        Part[] ps = isFp ? fp : face;
        for (int i = 0; i < ps.length; i++) {
            Part o = ps[i];
            float stg = isFp ? i * 35f : i * 40f;
            float aa = clamp((ti - stg) / (isFp ? 380f : 420f));
            float q = 1f - aa;
            float e = 1f - q * q * q;
            float sgn = (i % 2 == 1) ? 1f : -1f;
            float alpha = e;
            float rot = (1f - e) * sgn * (isFp ? 30f : 90f);
            float sc = 0.7f + 0.3f * e;
            float blur = (1f - e) * 10f;
            float trimF = isFp ? Math.min(1f, e * 1.3f) : 1f;
            float wmul = 1f, dx = 0f, dy = 0f, rot2 = 0f;
            if (pw <= 0f && ti > 420f && ti <= 770f) {
                wmul = 1f + 0.3f * (float) Math.sin((ti - 420f) / 350f * Math.PI * 2.0);
            }
            if (pw > 0f) {
                float en = ease(pw);
                dx = (mx - o.cx) * 0.85f * en;
                dy = (my - o.cy) * 0.85f * en;
                rot2 = sgn * (isFp ? (90f + i * 12f) : 140f) * en;
                sc *= 1f - 0.5f * en;
                wmul = 1f + 1.4f * (float) Math.sin(Math.PI * pw);
                alpha *= 1f - (float) Math.pow(pw, 1.5);
                blur = Math.max(blur, 8f * (float) Math.sin(Math.PI * pw));
            }
            c.save();
            c.translate(o.cx + dx, o.cy + dy);
            c.rotate(rot + rot2);
            c.scale(sc, sc);
            c.translate(-o.cx, -o.cy);
            strokePart(c, o, trimF, 6.5f * wmul, alpha * vis, blur);
            c.restore();
        }
        c.restore();

        c.translate(-100f, -100f);
        float oa = clamp((ti - 520f) / 250f) * (1f - clamp((ti - 1120f) / 150f));
        if (oa > 0f) {
            float spin = ease(clamp((ti - 520f) / 650f));
            float mrg = ease(clamp((ti - 970f) / 300f));
            float kk = (float) Math.sin(Math.PI * clamp((ti - 520f) / 650f));
            float rx = lerp(54f, 46f, mrg);
            float ry = lerp(rx * 0.45f, rx, mrg);
            for (int j = 0; j < 4; j++) {
                float deg = j * 45f + spin * 216f;
                tmp.set(-rx, -ry, rx, ry);
                ell.reset();
                ell.addOval(tmp, Path.Direction.CW);
                c.save();
                c.translate(100f, 100f);
                c.rotate(deg);
                drawGlow(c, ell, 3.5f + 3.5f * kk, oa * vis * 0.85f, 4f + 5f * kk);
                c.restore();
            }
        }
        float rf = clamp((ti - 970f) / 300f);
        if (rf > 0f) {
            blue.setAlpha(a(vis));
            blue.setStrokeWidth(6.5f);
            c.drawArc(arcRect, -90f, 360f * rf, false, blue);
        }
        strokePart(c, tick, clamp((ti - 1220f) / 250f), 6.5f, vis, 0f);
        c.restore();
    }
}
