package dev.bonu.unlockpop;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.PathMeasure;
import android.graphics.Rect;
import android.graphics.RectF;
import android.view.DisplayCutout;
import android.view.View;
import android.view.WindowInsets;
import android.view.animation.LinearInterpolator;

import java.util.List;

public class PopView extends View {
    static final float TOTAL = 1900f;
    private static final int BLUE = 0xFF378ADD;

    private final int mode;
    private final float dp;
    private final Paint blue = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint black = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path seg = new Path();
    private final Path[] brackets = new Path[4];
    private final Path[] face = new Path[4];
    private final Path[] fp = new Path[9];
    private final Path ring = new Path();
    private final Path tick = new Path();

    private PathMeasure[] pmFace;
    private PathMeasure[] pmFp;
    private PathMeasure pmRing;
    private PathMeasure pmTick;
    private float t;
    private boolean found;
    private float cx, cy, r0;

    public PopView(Context c, int mode) {
        super(c);
        this.mode = mode;
        this.dp = c.getResources().getDisplayMetrics().density;
        blue.setStyle(Paint.Style.STROKE);
        blue.setColor(BLUE);
        blue.setStrokeWidth(6.5f);
        blue.setStrokeCap(Paint.Cap.ROUND);
        blue.setStrokeJoin(Paint.Join.ROUND);
        black.setStyle(Paint.Style.FILL);
        black.setColor(0xFF000000);
        buildPaths();
        pmFace = new PathMeasure[face.length];
        for (int i = 0; i < face.length; i++) pmFace[i] = new PathMeasure(face[i], false);
        pmFp = new PathMeasure[fp.length];
        for (int i = 0; i < fp.length; i++) pmFp[i] = new PathMeasure(fp[i], false);
        pmRing = new PathMeasure(ring, false);
        pmTick = new PathMeasure(tick, false);
        cx = 0f;
        cy = dp * 20f;
        r0 = dp * 10f;
    }

    int windowHeight() {
        return (int) (dp * 160f);
    }

    private static Path line(float x1, float y1, float x2, float y2) {
        Path p = new Path();
        p.moveTo(x1, y1);
        p.lineTo(x2, y2);
        return p;
    }

    private void buildPaths() {
        Path b = new Path();
        b.moveTo(52, 78); b.lineTo(52, 62); b.arcTo(new RectF(52, 52, 72, 72), 180, 90, false); b.lineTo(78, 52);
        brackets[0] = b;
        b = new Path();
        b.moveTo(148, 78); b.lineTo(148, 62); b.arcTo(new RectF(128, 52, 148, 72), 0, -90, false); b.lineTo(122, 52);
        brackets[1] = b;
        b = new Path();
        b.moveTo(52, 122); b.lineTo(52, 138); b.arcTo(new RectF(52, 128, 72, 148), 180, -90, false); b.lineTo(78, 148);
        brackets[2] = b;
        b = new Path();
        b.moveTo(148, 122); b.lineTo(148, 138); b.arcTo(new RectF(128, 128, 148, 148), 0, 90, false); b.lineTo(122, 148);
        brackets[3] = b;

        face[0] = line(80, 84, 80, 98);
        face[1] = line(120, 84, 120, 98);
        Path nose = new Path();
        nose.moveTo(100, 88); nose.lineTo(100, 112); nose.quadTo(100, 118, 93, 118);
        face[2] = nose;
        Path mouth = new Path();
        mouth.moveTo(82, 130); mouth.quadTo(100, 144, 118, 130);
        face[3] = mouth;

        Path f = new Path();
        f.moveTo(48, 118); f.lineTo(48, 96); f.arcTo(new RectF(48, 44, 152, 148), 180, 180, false); f.lineTo(152, 106);
        fp[0] = f;
        f = new Path();
        f.moveTo(60, 138); f.lineTo(60, 98); f.arcTo(new RectF(60, 58, 140, 138), 180, 180, false); f.lineTo(140, 132);
        fp[1] = f;
        f = new Path();
        f.moveTo(72, 150); f.lineTo(72, 100); f.arcTo(new RectF(72, 72, 128, 128), 180, 180, false); f.lineTo(128, 142);
        fp[2] = f;
        f = new Path();
        f.moveTo(84, 160); f.lineTo(84, 102); f.arcTo(new RectF(84, 86, 116, 118), 180, 180, false); f.lineTo(116, 152);
        fp[3] = f;
        fp[4] = line(100, 114, 100, 168);
        f = new Path(); f.moveTo(48, 130); f.quadTo(48, 152, 62, 168); fp[5] = f;
        f = new Path(); f.moveTo(152, 120); f.quadTo(152, 148, 138, 166); fp[6] = f;
        f = new Path(); f.moveTo(66, 152); f.quadTo(70, 166, 80, 174); fp[7] = f;
        f = new Path(); f.moveTo(134, 160); f.quadTo(130, 170, 124, 176); fp[8] = f;

        ring.addArc(new RectF(54, 54, 146, 146), -90f, 359.9f);
        tick.moveTo(80, 102); tick.lineTo(94, 116); tick.lineTo(121, 86);
    }

    void start(final Runnable end) {
        ValueAnimator va = ValueAnimator.ofFloat(0f, TOTAL);
        va.setDuration((long) TOTAL);
        va.setInterpolator(new LinearInterpolator());
        va.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator a) {
                t = (Float) a.getAnimatedValue();
                invalidate();
            }
        });
        va.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator a) {
                end.run();
            }
        });
        va.start();
    }

    private void measureHole() {
        if (found) return;
        cx = getWidth() / 2f;
        try {
            WindowInsets wi = getRootWindowInsets();
            DisplayCutout dc = wi == null ? null : wi.getDisplayCutout();
            if (dc != null) {
                List<Rect> rs = dc.getBoundingRects();
                Rect best = null;
                for (Rect r : rs) {
                    if (best == null || r.top < best.top) best = r;
                }
                if (best != null) {
                    cx = best.exactCenterX();
                    cy = best.exactCenterY();
                    r0 = Math.min(best.width(), best.height()) / 2f;
                    found = true;
                }
            }
        } catch (Throwable ignored) {
        }
    }

    private static float clamp(float x) {
        return x < 0f ? 0f : (x > 1f ? 1f : x);
    }

    private static float lerp(float a, float b, float k) {
        return a + (b - a) * k;
    }

    private static float overshoot(float x) {
        float s = 1.2f;
        x -= 1f;
        return x * x * ((s + 1f) * x + s) + 1f;
    }

    private void trim(Canvas c, Path p, PathMeasure pm, float f) {
        if (f <= 0f) return;
        if (f >= 1f) {
            c.drawPath(p, blue);
            return;
        }
        seg.reset();
        pm.getSegment(0f, pm.getLength() * f, seg, true);
        c.drawPath(seg, blue);
    }

    @Override
    protected void onDraw(Canvas c) {
        if (!found && t < 250f) measureHole();
        float w = dp * 118f;
        float h = dp * 118f;
        float tail = TOTAL - 310f;
        float pop;
        if (t < 260f) {
            pop = overshoot(t / 260f);
        } else if (t < tail) {
            pop = 1f;
        } else {
            float k = clamp((t - tail) / 310f);
            pop = 1f - k * k * k;
        }
        float rr = r0 + dp * 1.5f;
        float top = Math.max(0f, cy - rr);
        float l = lerp(cx - rr, cx - w / 2f, pop);
        float rt = lerp(cx + rr, cx + w / 2f, pop);
        float bot = lerp(cy + rr, top + h, pop);
        float rad = Math.max(0f, lerp(rr, dp * 32f, pop));
        c.drawRoundRect(l, top, rt, bot, rad, rad, black);
        if (pop < 0.55f) return;
        float ti = t - 120f;
        if (ti < 0f) return;
        drawIcon(c, cx, top + h * 0.56f, dp * 118f, ti, clamp((pop - 0.55f) / 0.45f));
    }

    private void drawIcon(Canvas c, float x, float y, float size, float ti, float vis) {
        c.save();
        c.translate(x, y);
        float s = size / 200f;
        c.scale(s, s);
        float pw = clamp((ti - 450f) / 300f);
        if (pw < 1f) {
            c.save();
            float a1 = vis;
            if (pw > 0f) {
                boolean early = pw < 0.6f;
                float k = early ? pw / 0.6f : (pw - 0.6f) / 0.4f;
                float rot = early ? lerp(0f, -6f, k) : lerp(-6f, 10f, k);
                float sc = early ? lerp(1f, 0.8f, k) : lerp(0.8f, 0.45f, k);
                float al = early ? lerp(1f, 0.8f, k) : lerp(0.8f, 0f, k);
                c.rotate(rot);
                c.scale(sc, sc);
                c.skew((float) (0.18 * Math.sin(Math.PI * 2 * pw)), 0f);
                a1 *= al;
            }
            c.translate(-100f, -100f);
            blue.setAlpha((int) (255f * a1));
            drawScan(c, ti);
            c.restore();
        }
        if (pw > 0f && pw < 1f) {
            blue.setAlpha((int) (255f * vis * 0.5f * (float) Math.sin(Math.PI * pw)));
            blue.setStrokeWidth(2f);
            c.drawCircle(0f, 0f, lerp(70f, 46f, pw), blue);
            blue.setStrokeWidth(6.5f);
        }
        blue.setAlpha((int) (255f * vis));
        c.translate(-100f, -100f);
        trim(c, ring, pmRing, clamp((ti - 650f) / 300f));
        trim(c, tick, pmTick, clamp((ti - 900f) / 220f));
        c.restore();
    }

    private void drawScan(Canvas c, float ti) {
        if (mode == 0) {
            float pf = clamp(ti / 450f);
            float sc = 1f - 0.1f * (float) Math.sin(Math.PI * pf);
            c.save();
            c.translate(100f, 100f);
            c.scale(sc, sc);
            c.translate(-100f, -100f);
            for (Path p : brackets) c.drawPath(p, blue);
            c.restore();
            for (int i = 0; i < face.length; i++) trim(c, face[i], pmFace[i], clamp((ti - i * 50f) / 300f));
        } else {
            c.save();
            c.translate(100f, 100f);
            c.scale(0.78f, 0.78f);
            c.translate(-100f, -110f);
            for (int i = 0; i < fp.length; i++) trim(c, fp[i], pmFp[i], clamp((ti - i * 35f) / 300f));
            c.restore();
        }
    }
}
