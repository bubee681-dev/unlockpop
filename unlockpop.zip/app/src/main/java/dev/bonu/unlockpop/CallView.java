package dev.bonu.unlockpop;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.RectF;
import android.text.TextPaint;
import android.text.TextUtils;
import android.view.Choreographer;
import android.view.DisplayCutout;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowInsets;

import java.util.List;

/** Incoming / ongoing call card that pops out of the camera hole. */
public class CallView extends View {
    interface Listener {
        void onAnswer();

        void onDecline();

        void onEnd();

        void onDone();
    }

    static final int RING = 0, CALL = 1, OUT = 2;

    int state = RING;
    private String title, sub;
    private final boolean dots;
    private final float dp;
    private final Paint black = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint ringP = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint nameP = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint subP = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final TextPaint btnP = new TextPaint(Paint.ANTI_ALIAS_FLAG);
    private final RectF decR = new RectF(), ansR = new RectF(), endR = new RectF();
    private Listener listener;
    private Runnable firstFrame;
    private float clock, tA, tO;
    private boolean found, finished;
    private float cx, cy, r0;

    private final Choreographer.FrameCallback ticker = new Choreographer.FrameCallback() {
        private long last;

        @Override
        public void doFrame(long ns) {
            if (last != 0) {
                float dt = (ns - last) / 1000000f;
                clock += Math.min(dt, 26f);
            }
            last = ns;
            if (state == OUT && clock - tO > 700f) {
                if (!finished && listener != null) {
                    finished = true;
                    listener.onDone();
                }
                return;
            }
            invalidate();
            Choreographer.getInstance().postFrameCallback(this);
        }
    };

    public CallView(Context c, String title, String sub, boolean dots) {
        super(c);
        this.title = title == null ? "Unknown" : title;
        this.sub = sub == null ? "" : sub;
        this.dots = dots;
        dp = c.getResources().getDisplayMetrics().density;
        black.setStyle(Paint.Style.FILL);
        black.setColor(0xFF000000);
        ringP.setStyle(Paint.Style.STROKE);
        ringP.setStrokeWidth(dp * 2f);
        ringP.setColor(0xFF30D158);
        nameP.setColor(0xFFFFFFFF);
        nameP.setTextSize(dp * 16f);
        nameP.setFakeBoldText(true);
        subP.setColor(0xFF9AA0AD);
        subP.setTextSize(dp * 12.5f);
        btnP.setColor(0xFFFFFFFF);
        btnP.setTextSize(dp * 13f);
        btnP.setFakeBoldText(true);
        btnP.setTextAlign(Paint.Align.CENTER);
        cy = dp * 20f;
        r0 = dp * 10f;
    }

    int windowWidth() {
        return (int) (dp * 312f);
    }

    int windowHeight() {
        return (int) (dp * 136f);
    }

    void setListener(Listener l) {
        listener = l;
    }

    void setOnFirstFrame(Runnable r) {
        firstFrame = r;
    }

    void start() {
        Choreographer.getInstance().postFrameCallback(ticker);
    }

    void update(String t, String s) {
        if (t != null) title = t;
        if (s != null) sub = s;
        invalidate();
    }

    void answered() {
        if (state == RING) {
            state = CALL;
            tA = clock;
        }
    }

    void collapse() {
        if (state != OUT) {
            state = OUT;
            tO = clock;
        }
    }

    private void measureHole() {
        if (found) return;
        cx = getWidth() / 2f;
        try {
            WindowInsets wi = getRootWindowInsets();
            DisplayCutout dc = wi == null ? null : wi.getDisplayCutout();
            if (dc != null) {
                List<Rect> rs = dc.getBoundingRects();
                Rect best = null;
                for (Rect r : rs) {
                    if (best == null || r.top < best.top) best = r;
                }
                if (best != null) {
                    cx = best.exactCenterX();
                    cy = best.exactCenterY();
                    r0 = Math.min(best.width(), best.height()) / 2f;
                    found = true;
                }
            }
        } catch (Throwable ignored) {
        }
    }

    private static float clamp(float x) {
        return x < 0f ? 0f : (x > 1f ? 1f : x);
    }

    private static float lerp(float a, float b, float k) {
        return a + (b - a) * k;
    }

    private static float ease(float x) {
        return x * x * (3f - 2f * x);
    }

    private static float spring(float x) {
        x = clamp(x);
        return 1f - (float) (Math.exp(-6.5 * x) * Math.cos(3.0 * Math.PI * x));
    }

    private static int a(float x) {
        return (int) (255f * clamp(x));
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        if (e.getAction() == MotionEvent.ACTION_UP && listener != null) {
            float x = e.getX(), y = e.getY();
            if (state == RING && clock > 500f) {
                if (decR.contains(x, y)) listener.onDecline();
                else if (ansR.contains(x, y)) listener.onAnswer();
            } else if (state == CALL && endR.contains(x, y)) {
                listener.onEnd();
            }
        }
        return true;
    }

    @Override
    protected void onDraw(Canvas c) {
        if (firstFrame != null) {
            Runnable fr = firstFrame;
            firstFrame = null;
            post(fr);
        }
        if (!found && clock < 250f) measureHole();
        float t = clock;
        float u = state == OUT ? clock - tO : -1f;
        float cw = dp * 296f, ch = dp * 124f, cr = dp * 32f;
        float rr = r0 + dp * 1.5f;
        float top = Math.max(0f, cy - rr);
        float w, h, rad, k;
        if (state == OUT) {
            if (u < 120f) {
                k = ease(u / 120f);
                w = lerp(cw, cw * 1.04f, k);
                h = lerp(ch, ch * 0.55f, k);
                rad = lerp(cr, cr * 0.7f, k);
            } else {
                k = clamp((u - 120f) / 280f);
                float k3 = k * k * k;
                w = lerp(cw * 1.04f, 2f * rr, k3);
                h = lerp(ch * 0.55f, 2f * rr, k3);
                rad = lerp(cr * 0.7f, rr, k3);
            }
        } else if (t < 100f) {
            k = ease(t / 100f);
            w = lerp(2f * rr, 3.4f * rr, k);
            h = 2f * rr;
            rad = rr;
        } else if (t < 400f) {
            k = spring((t - 100f) / 300f);
            w = lerp(3.4f * rr, cw, k);
            h = lerp(2f * rr, ch, k);
            rad = lerp(rr, cr, k);
        } else {
            w = cw;
            h = ch;
            rad = cr;
        }
        rad = Math.max(0f, Math.min(rad, Math.min(w, h) / 2f));
        c.drawRoundRect(cx - w / 2f, top, cx + w / 2f, top + h, rad, rad, black);

        float al = clamp((t - 260f) / 200f) * (state == OUT ? 1f - clamp(u / 120f) : 1f);
        if (al > 0f && w > cw * 0.9f) drawContent(c, cx - cw / 2f, top, cw, ch, al);

        if (dots) {
            float frac, rs;
            if (state != OUT) {
                float e = ease(clamp(t / 160f));
                frac = 1f - e;
                rs = 1f - 0.4f * e;
            } else if (u < 250f) {
                frac = 0f;
                rs = 0.6f;
            } else {
                float s = spring((u - 250f) / 320f);
                frac = s;
                rs = 0.6f + 0.4f * Math.min(1f, s);
            }
            Dots.draw(c, black, cx, cy, r0, Config.layout, frac, rs, Config.dotDx * dp, Config.dotDy * dp);
        }
    }

    private void pill(Canvas c, RectF r, int color, String label, float alpha) {
        fill.setColor(color);
        fill.setAlpha(a(alpha));
        c.drawRoundRect(r, r.height() / 2f, r.height() / 2f, fill);
        btnP.setAlpha(a(alpha));
        c.drawText(label, r.centerX(), r.centerY() + dp * 4.5f, btnP);
    }

    private void drawContent(Canvas c, float l, float top, float cw, float ch, float al) {
        float ay = top + dp * 62f;
        float ax = l + dp * 40f;
        if (state == RING) {
            float q = (clock % 1200f) / 1200f;
            ringP.setAlpha(a(al * 0.5f * (1f - q)));
            c.drawCircle(ax, ay, dp * (20f + 11f * q), ringP);
        }
        fill.setColor(0xFF3B4A63);
        fill.setAlpha(a(al));
        c.drawCircle(ax, ay, dp * 20f, fill);
        btnP.setAlpha(a(al));
        boolean isNum = title.length() == 0 || !Character.isLetter(title.charAt(0));
        c.drawText(isNum ? "?" : title.substring(0, 1).toUpperCase(), ax, ay + dp * 5.5f, btnP);

        float tx = l + dp * 71f;
        float maxW = cw - dp * 71f - dp * 16f;
        nameP.setAlpha(a(al));
        subP.setAlpha(a(al));
        String nm = TextUtils.ellipsize(title, nameP, maxW, TextUtils.TruncateAt.END).toString();
        c.drawText(nm, tx, ay - dp * 3f, nameP);
        String line;
        if (state == CALL) {
            long s = (long) ((clock - tA) / 1000f);
            line = "On call  " + two(s / 60) + ":" + two(s % 60);
        } else {
            line = sub;
        }
        String sl = TextUtils.ellipsize(line, subP, maxW, TextUtils.TruncateAt.END).toString();
        c.drawText(sl, tx, ay + dp * 14f, subP);

        float by = top + ch - dp * 46f;
        float bh = dp * 32f;
        float bw = dp * 118f;
        decR.set(l + dp * 16f, by, l + dp * 16f + bw, by + bh);
        ansR.set(l + cw - dp * 16f - bw, by, l + cw - dp * 16f, by + bh);
        endR.set(l + dp * 16f, by, l + cw - dp * 16f, by + bh);
        if (state == RING || (state == CALL && clock - tA < 200f)) {
            float ra = state == CALL ? 1f - (clock - tA) / 200f : 1f;
            pill(c, decR, 0xFFFF453A, "Decline", al * ra);
            pill(c, ansR, 0xFF30D158, "Answer", al * ra);
        }
        if (state == CALL) pill(c, endR, 0xFFFF453A, "End call", al * clamp((clock - tA - 100f) / 200f));
    }

    private static String two(long n) {
        return n < 10 ? "0" + n : String.valueOf(n);
    }
}
