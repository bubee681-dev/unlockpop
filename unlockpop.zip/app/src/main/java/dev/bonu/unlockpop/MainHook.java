package dev.bonu.unlockpop;

import android.app.Application;
import android.app.Instrumentation;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Handler;
import android.os.HandlerThread;
import android.os.UserHandle;
import android.service.notification.StatusBarNotification;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodHook;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MainHook implements IXposedHookLoadPackage {

    static final String ACTION = "dev.bonu.unlockpop.PLAY";
    static final String ACTION_CALL = "dev.bonu.unlockpop.CALL";
    static final String ACTION_LIVE = "dev.bonu.unlockpop.LIVE";
    static final String ACTION_CFG = "dev.bonu.unlockpop.CFG";
    static final String UI_PKG = "com.android.systemui";
    private static final String TAG = "UnlockPop: ";

    private static final Pattern FP1 = Pattern.compile("miui_keyguard(?:\\(\\s*\\d+\\))?:\\s*unlock keyguard by fp\\b");
    private static final Pattern FP2 = Pattern.compile("onAuthenticated\\(true\\).*Fingerprint\\w*AuthenticationClient");
    private static final Pattern FACE1 = Pattern.compile("(?i)miui_keyguard.*unlock keyguard by face");
    private static final Pattern FACE2 = Pattern.compile("(?i)\\bface\\w*.*(authenticated\\(true\\)|authenticated=true|authenticationsucceeded|authentication succeeded|authenticated true)");
    private static final Pattern SUCC = Pattern.compile("Succeeded\\(biometricSourceType=(\\w+)");

    private static final ThreadLocal<Boolean> BUSY = new ThreadLocal<>();
    private static HandlerThread sender;
    private static Handler senderHandler;
    private static long dbgWindow;
    private static int dbgBudget;

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lp) {
        try {
            if ("android".equals(lp.packageName)) {
                hookLog(true);
                hookNotifications(lp.classLoader);
            } else if (UI_PKG.equals(lp.packageName)) {
                hookLog(false);
                hookUiStart();
            }
        } catch (Throwable t) {
            XposedBridge.log(TAG + "setup failed: " + t);
        }
    }

    private void hookLog(final boolean inServer) throws Throwable {
        Class<?> log = Class.forName("android.util.Log");
        int n = XposedBridge.hookAllMethods(log, "println_native", new XC_MethodHook() {
            @Override
            protected void beforeHookedMethod(MethodHookParam param) {
                if (BUSY.get() != null) return;
                Object[] a = param.args;
                if (a == null || a.length < 4) return;
                if (!(a[2] instanceof String) || !(a[3] instanceof String)) return;
                String tag = (String) a[2];
                String msg = (String) a[3];
                if (!candidate(tag, msg)) return;
                BUSY.set(Boolean.TRUE);
                try {
                    handle(tag + ": " + msg, inServer);
                } catch (Throwable t) {
                    XposedBridge.log(TAG + t);
                } finally {
                    BUSY.remove();
                }
            }
        }).size();
        XposedBridge.log(TAG + "hooked Log.println_native (" + n + ") in " + (inServer ? "system_server" : "systemui"));
    }

    private static boolean candidate(String tag, String msg) {
        return tag.equals("miui_keyguard")
                || tag.contains("AuthenticationClient")
                || tag.contains("AppLock")
                || tag.contains("Face")
                || tag.contains("Biometric")
                || msg.contains("biometricSourceType")
                || msg.contains("AuthenticationClient")
                || msg.contains("Face")
                || msg.contains("face");
    }

    private static void handle(String line, boolean inServer) {
        String type = null;
        if (FP1.matcher(line).find() || FP2.matcher(line).find()) {
            type = "finger";
        } else if (FACE1.matcher(line).find() || FACE2.matcher(line).find()) {
            type = "face";
        } else {
            Matcher m = SUCC.matcher(line);
            if (m.find()) {
                String s = m.group(1);
                if ("FACE".equalsIgnoreCase(s)) type = "face";
                else if ("FINGERPRINT".equalsIgnoreCase(s)) type = "finger";
            }
        }
        if (type == null) {
            debug(line);
            return;
        }
        XposedBridge.log(TAG + "event " + type + " seen in " + (inServer ? "server" : "systemui"));
        if (inServer) sendToUi(type);
        else Overlay.play(type, 0, null, false);
    }

    private static void debug(String line) {
        long now = System.currentTimeMillis();
        if (now - dbgWindow > 60000) {
            dbgWindow = now;
            dbgBudget = 80;
        }
        if (dbgBudget-- > 0) {
            XposedBridge.log(TAG + "[dbg] " + (line.length() > 300 ? line.substring(0, 300) : line));
        }
    }

    private static synchronized void sendToUi(final String type) {
        if (sender == null) {
            sender = new HandlerThread("unlockpop-send");
            sender.start();
            senderHandler = new Handler(sender.getLooper());
        }
        senderHandler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    Class<?> at = Class.forName("android.app.ActivityThread");
                    Object cur = at.getMethod("currentActivityThread").invoke(null);
                    Context sys = (Context) at.getMethod("getSystemContext").invoke(cur);
                    Intent i = new Intent(ACTION).setPackage(UI_PKG).putExtra("type", type);
                    i.addFlags(Intent.FLAG_RECEIVER_FOREGROUND);
                    UserHandle all = (UserHandle) UserHandle.class.getField("ALL").get(null);
                    sys.sendBroadcastAsUser(i, all);
                } catch (Throwable t) {
                    XposedBridge.log(TAG + "broadcast failed: " + t);
                }
            }
        });
    }

    private void hookUiStart() {
        int n = XposedBridge.hookAllMethods(Instrumentation.class, "callApplicationOnCreate", new XC_MethodHook() {
            @Override
            protected void afterHookedMethod(MethodHookParam param) {
                try {
                    if (param.args != null && param.args.length > 0 && param.args[0] instanceof Application) {
                        Overlay.init((Application) param.args[0]);
                    }
                } catch (Throwable t) {
                    XposedBridge.log(TAG + t);
                }
            }
        }).size();
        XposedBridge.log(TAG + "hooked app start (" + n + ")");
    }

    // ---- call notifications (system_server) ----
    private void hookNotifications(ClassLoader cl) {
        try {
            Class<?> nms = Class.forName("com.android.server.notification.NotificationManagerService", false, cl);
            int n = XposedBridge.hookAllMethods(nms, "enqueueNotificationInternal", new XC_MethodHook() {
                @Override
                protected void beforeHookedMethod(MethodHookParam param) {
                    try {
                        onNotification(param.args);
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + "notif hook: " + t);
                    }
                }
            }).size();
            XposedBridge.log(TAG + "hooked notifications (" + n + ")");
            int r = XposedBridge.hookAllMethods(nms, "removeFromNotificationListsLocked", new XC_MethodHook() {
                @Override
                protected void afterHookedMethod(MethodHookParam param) {
                    try {
                        onRemoved(param.args);
                    } catch (Throwable t) {
                        XposedBridge.log(TAG + "removal hook: " + t);
                    }
                }
            }).size();
            XposedBridge.log(TAG + "hooked notification removal (" + r + ")");
        } catch (Throwable t) {
            XposedBridge.log(TAG + "notification hook failed: " + t);
        }
    }

    private static boolean has(CharSequence s, String... keys) {
        if (s == null) return false;
        String l = s.toString().toLowerCase();
        for (String k : keys) if (l.contains(k)) return true;
        return false;
    }

    private static void onNotification(Object[] args) {
        if (args == null) return;
        Notification n = null;
        String pkg = null;
        for (Object a : args) {
            if (n == null && a instanceof Notification) n = (Notification) a;
            if (pkg == null && a instanceof String) pkg = (String) a;
        }
        if (n == null) return;
        if (isCountdown(n)) {
            sendLive("timer", pkg, n.when);
            return;
        }
        boolean callish = Notification.CATEGORY_CALL.equals(n.category)
                || (pkg != null && (pkg.contains("dialer") || pkg.contains("incallui")) && n.fullScreenIntent != null);
        if (!callish) return;
        PendingIntent ans = null, dec = null, end = null;
        if (n.actions != null) {
            for (Notification.Action a : n.actions) {
                if (a == null || a.actionIntent == null) continue;
                if (has(a.title, "answer", "accept")) ans = a.actionIntent;
                else if (has(a.title, "decline", "reject", "dismiss")) dec = a.actionIntent;
                else if (has(a.title, "hang up", "hangup", "end call", "disconnect")) end = a.actionIntent;
            }
        }
        int kind;
        if (ans != null || dec != null) kind = 0;
        else if (end != null) kind = 1;
        else {
            debug("call-ish notification without known actions from " + pkg);
            return;
        }
        String title = null, text = null;
        if (n.extras != null) {
            CharSequence t1 = n.extras.getCharSequence(Notification.EXTRA_TITLE);
            CharSequence t2 = n.extras.getCharSequence(Notification.EXTRA_TEXT);
            if (t1 != null) title = t1.toString();
            if (t2 != null) text = t2.toString();
        }
        XposedBridge.log(TAG + "call notification kind=" + kind + " from " + pkg);
        sendCall(kind, title, text, ans, dec, end);
    }

    private static synchronized void sendCall(final int kind, final String title, final String text,
                                              final PendingIntent ans, final PendingIntent dec, final PendingIntent end) {
        if (sender == null) {
            sender = new HandlerThread("unlockpop-send");
            sender.start();
            senderHandler = new Handler(sender.getLooper());
        }
        senderHandler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    Class<?> at = Class.forName("android.app.ActivityThread");
                    Object cur = at.getMethod("currentActivityThread").invoke(null);
                    Context sys = (Context) at.getMethod("getSystemContext").invoke(cur);
                    Intent i = new Intent(ACTION_CALL).setPackage(UI_PKG)
                            .putExtra("kind", kind).putExtra("title", title).putExtra("text", text);
                    if (ans != null) i.putExtra("ans", ans);
                    if (dec != null) i.putExtra("dec", dec);
                    if (end != null) i.putExtra("end", end);
                    i.addFlags(Intent.FLAG_RECEIVER_FOREGROUND);
                    UserHandle all = (UserHandle) UserHandle.class.getField("ALL").get(null);
                    sys.sendBroadcastAsUser(i, all);
                } catch (Throwable t) {
                    XposedBridge.log(TAG + "call broadcast failed: " + t);
                }
            }
        });
    }

    private static boolean isCountdown(Notification n) {
        return n.extras != null
                && n.extras.getBoolean(Notification.EXTRA_SHOW_CHRONOMETER)
                && n.extras.getBoolean(Notification.EXTRA_CHRONOMETER_COUNT_DOWN);
    }

    private static void onRemoved(Object[] args) throws Throwable {
        if (args == null || args.length == 0 || args[0] == null) return;
        Object rec = args[0];
        Notification n = (Notification) rec.getClass().getMethod("getNotification").invoke(rec);
        if (n == null || !isCountdown(n)) return;
        Object sbn = rec.getClass().getMethod("getSbn").invoke(rec);
        String pkg = sbn == null ? null : ((android.service.notification.StatusBarNotification) sbn).getPackageName();
        sendLive("timerOff", pkg, 0L);
    }

    private static synchronized void sendLive(final String type, final String key, final long end) {
        if (sender == null) {
            sender = new HandlerThread("unlockpop-send");
            sender.start();
            senderHandler = new Handler(sender.getLooper());
        }
        senderHandler.post(new Runnable() {
            @Override
            public void run() {
                try {
                    Class<?> at = Class.forName("android.app.ActivityThread");
                    Object cur = at.getMethod("currentActivityThread").invoke(null);
                    Context sys = (Context) at.getMethod("getSystemContext").invoke(cur);
                    Intent i = new Intent(ACTION_LIVE).setPackage(UI_PKG)
                            .putExtra("type", type).putExtra("key", key).putExtra("end", end);
                    i.addFlags(Intent.FLAG_RECEIVER_FOREGROUND);
                    UserHandle all = (UserHandle) UserHandle.class.getField("ALL").get(null);
                    sys.sendBroadcastAsUser(i, all);
                } catch (Throwable t) {
                    XposedBridge.log(TAG + "live broadcast failed: " + t);
                }
            }
        });
    }
}
